"""
coin.py
=======
Monedas recolectables que sueltan los enemigos al morir. El jugador las
recoge tocandolas, y se usan en la tienda (shop_screen.py) para comprar
mejoras permanentes.
"""
from kivy.uix.widget import Widget
from kivy.graphics import Color, Ellipse

import config


class Coin(Widget):
    def __init__(self, x, y, value=config.COIN_VALUE, **kwargs):
        super().__init__(**kwargs)
        self.size = (18, 18)
        self.size_hint = (None, None)
        self.pos = (x, y)
        self.value = value
        self.active = True

        self.bind(pos=self._redraw)
        self._redraw()

    def _redraw(self, *args):
        self.canvas.clear()
        with self.canvas:
            Color(*config.COLOR_COIN)
            Ellipse(pos=self.pos, size=self.size)
            Color(0.5, 0.4, 0.0, 1)
            Ellipse(pos=(self.x + 5, self.y + 5), size=(8, 8))

    def update(self, dt):
        """Punto de extension: aqui se podria anadir una animacion de
        flotar/brillar. Se deja vacio para mantener el rendimiento en
        moviles con muchas monedas en pantalla."""
        pass
