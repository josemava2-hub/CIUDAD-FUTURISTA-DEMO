"""
config.py
=========
Configuracion global de "Ciudad Futurista".

Aqui se guardan TODAS las constantes ajustables del juego: velocidades,
vidas, colores, tamanos, configuracion de red, etc.

Si quieres cambiar la dificultad, el balance del juego o los colores,
este es el primer archivo al que deberias venir.

IMPORTANTE: este archivo NO importa Kivy a proposito. De esta forma,
"server.py" (el servidor del modo multijugador) puede usar estas mismas
constantes sin necesidad de tener Kivy instalado, ya que el servidor
puede ejecutarse en un equipo sin pantalla (headless).
"""

# =====================================================================
# VENTANA Y MUNDO DEL JUEGO
# =====================================================================
WINDOW_WIDTH = 900
WINDOW_HEIGHT = 520

# El "mundo" es mas ancho que la pantalla: la camara sigue al jugador
# dentro de este espacio (efecto de camara 2D con scroll lateral).
WORLD_WIDTH = 2600
WORLD_HEIGHT = 520

# =====================================================================
# JUGADOR (ROBOT)
# =====================================================================
PLAYER_SPEED = 220              # pixeles por segundo
PLAYER_MAX_HEALTH = 100
PLAYER_SIZE = (46, 62)          # ancho, alto
PLAYER_SHOOT_COOLDOWN = 0.30    # segundos minimos entre disparos
PLAYER_BULLET_SPEED = 480
PLAYER_BULLET_DAMAGE = 20

# =====================================================================
# ENEMIGOS (ALIENS)
# =====================================================================
# Alien normal: equilibrado
ALIEN_SPEED = 90
ALIEN_HEALTH = 40
ALIEN_DAMAGE = 8

# Alien rapido: poca vida, mucha velocidad
FAST_ALIEN_SPEED = 155
FAST_ALIEN_HEALTH = 25
FAST_ALIEN_DAMAGE = 6

# Alien tanque: lento, mucha vida
TANK_ALIEN_SPEED = 55
TANK_ALIEN_HEALTH = 95
TANK_ALIEN_DAMAGE = 14

# Mini-jefe
MINIBOSS_SPEED = 70
MINIBOSS_HEALTH = 260
MINIBOSS_DAMAGE = 18

# Jefe final de cada tanda
BOSS_SPEED = 60
BOSS_HEALTH = 650
BOSS_DAMAGE = 25

# Cuanto tiempo (segundos) debe pasar entre golpes de contacto del mismo
# enemigo contra el mismo jugador.
ENEMY_CONTACT_COOLDOWN = 1.0

# =====================================================================
# MONEDAS
# =====================================================================
COIN_VALUE = 10
COIN_DROP_CHANCE = 0.6   # probabilidad de que un alien normal suelte moneda
COIN_PICKUP_RADIUS = 30

# =====================================================================
# NIVELES / OLEADAS
# =====================================================================
ENEMIES_PER_LEVEL_BASE = 4          # enemigos en el nivel 1
ENEMIES_PER_LEVEL_INCREMENT = 2     # enemigos extra por cada nivel
ENEMY_SPAWN_INTERVAL = 1.4          # segundos entre apariciones de enemigos
MINIBOSS_EVERY_N_LEVELS = 3         # cada cuantos niveles aparece un mini-jefe
BOSS_EVERY_N_LEVELS = 5             # cada cuantos niveles aparece un jefe

# =====================================================================
# MEJORAS DE LA TIENDA
# =====================================================================
UPGRADE_COSTS = {
    "speed": 50,
    "damage": 60,
    "max_health": 70,
}
UPGRADE_MAX_LEVEL = 5
UPGRADE_SPEED_BONUS_PER_LEVEL = 20     # +pixeles/seg por nivel de mejora
UPGRADE_DAMAGE_BONUS_PER_LEVEL = 5     # +dano por disparo por nivel de mejora
UPGRADE_HEALTH_BONUS_PER_LEVEL = 20    # +vida maxima por nivel de mejora

# =====================================================================
# RED / MULTIJUGADOR
# =====================================================================
DEFAULT_SERVER_PORT = 5555
SERVER_TICK_RATE = 20            # actualizaciones del servidor por segundo
CLIENT_INPUT_SEND_RATE = 20      # envios de entrada del cliente por segundo
MAX_PLAYERS = 4
NETWORK_CONNECT_TIMEOUT = 5.0    # segundos de espera al conectar

# =====================================================================
# COLORES (formato RGBA 0.0-1.0, el que usa Kivy)
# =====================================================================
COLOR_SKY = (0.12, 0.35, 0.62, 1)
COLOR_SKY_DARK = (0.05, 0.16, 0.32, 1)
COLOR_BUILDING_1 = (0.35, 0.38, 0.46, 1)
COLOR_BUILDING_2 = (0.24, 0.27, 0.34, 1)
COLOR_BUILDING_WINDOW = (0.80, 0.90, 1.0, 0.9)
COLOR_BUILDING_WINDOW_LIT = (1.0, 0.85, 0.35, 0.9)
COLOR_GROUND = (0.13, 0.14, 0.20, 1)
COLOR_GROUND_LINE = (0.20, 0.85, 0.90, 0.5)

COLOR_ROBOT_BODY = (0.55, 0.60, 0.68, 1)
COLOR_ROBOT_BODY_DEAD = (0.28, 0.28, 0.30, 1)
COLOR_ROBOT_ACCENT = (0.10, 0.85, 0.90, 1)
COLOR_ROBOT_ACCENT_REMOTE = (0.85, 0.55, 0.10, 1)

COLOR_ALIEN = (0.25, 0.85, 0.35, 1)
COLOR_FAST_ALIEN = (0.85, 0.80, 0.15, 1)
COLOR_TANK_ALIEN = (0.55, 0.25, 0.80, 1)
COLOR_MINIBOSS = (0.90, 0.45, 0.15, 1)
COLOR_BOSS = (0.85, 0.10, 0.15, 1)

COLOR_COIN = (1.0, 0.85, 0.20, 1)
COLOR_BULLET_PLAYER = (0.25, 0.90, 1.0, 1)
COLOR_BULLET_ENEMY = (1.0, 0.30, 0.30, 1)

COLOR_HEALTH_BG = (0.20, 0.05, 0.05, 1)
COLOR_HEALTH_FG = (0.20, 0.90, 0.30, 1)
COLOR_HEALTH_FG_LOW = (0.90, 0.20, 0.20, 1)
