"""
client.py
=========
Cliente de red para el modo multijugador de "Ciudad Futurista".

Se conecta al servidor (server.py) mediante un socket TCP, envia la
entrada local del jugador (hacia donde se mueve, si dispara) y recibe
"snapshots" (fotografias) del estado completo del juego, que la pantalla
de juego (game_screen.py) usa para dibujar a todos los jugadores,
enemigos, monedas y disparos.

Este archivo NO depende de Kivy: toda la logica de red es Python puro
(socket + threading + queue), lo que lo hace facil de probar por
separado y reutilizable si en el futuro se quisiera portar el juego a
otro motor grafico.
"""
import queue
import socket
import threading

from protocol import (
    encode_message,
    MSG_JOIN,
    MSG_INPUT,
    MSG_WELCOME,
    MSG_STATE,
    MSG_PLAYER_LEFT,
    MSG_SERVER_FULL,
    SocketLineReader,
)

import config


class NetworkClient:
    """Cliente de red simple, pensado para ser sondeado (poll) desde el
    bucle de actualizacion de Kivy (Clock.schedule_interval) en lugar de
    usar callbacks, para evitar tener que sincronizar hilos manualmente
    en cada punto del codigo de la interfaz.
    """

    def __init__(self):
        self.sock = None
        self.reader = None
        self.connected = False
        self.player_id = None
        self.server_full = False
        self.error_message = None
        self.incoming_states = queue.Queue()

        self._recv_thread = None
        self._running = False

    # ----------------- CONEXION -----------------
    def connect(self, host, port, player_name, timeout=config.NETWORK_CONNECT_TIMEOUT):
        """Intenta conectarse al servidor. Devuelve True/False.

        Nota: esta llamada es BLOQUEANTE durante como mucho "timeout"
        segundos (por defecto unos pocos segundos). Se invoca desde la
        pantalla de multijugador antes de entrar a la partida, asi que
        una pequena espera es aceptable; para una version mas avanzada
        se podria lanzar en un hilo aparte para no congelar la interfaz
        ni un instante.
        """
        try:
            self.sock = socket.create_connection((host, port), timeout=timeout)
            self.sock.settimeout(None)  # a partir de aqui, lecturas bloqueantes normales
        except (OSError, socket.timeout) as exc:
            self.error_message = f"No se pudo conectar a {host}:{port} ({exc})"
            return False

        self.reader = SocketLineReader(self.sock)
        self._running = True
        self.connected = True
        self.error_message = None

        self._send_raw(encode_message(MSG_JOIN, {"name": player_name}))

        self._recv_thread = threading.Thread(target=self._receive_loop, daemon=True)
        self._recv_thread.start()
        return True

    def _receive_loop(self):
        while self._running:
            try:
                for message in self.reader.read_messages():
                    self._handle_message(message)
            except (ConnectionError, OSError):
                self.connected = False
                if not self.error_message:
                    self.error_message = "Se perdio la conexion con el servidor."
                break

    def _handle_message(self, message):
        msg_type = message.get("type")
        if msg_type == MSG_WELCOME:
            self.player_id = message.get("player_id")
        elif msg_type == MSG_STATE:
            self.incoming_states.put(message)
        elif msg_type == MSG_SERVER_FULL:
            self.server_full = True
            self.error_message = "El servidor esta lleno (maximo de jugadores alcanzado)."
            self.connected = False
        elif msg_type == MSG_PLAYER_LEFT:
            # El siguiente "state" ya no incluira a ese jugador, asi que
            # no hace falta procesar nada especial aqui.
            pass

    # ----------------- ENVIO -----------------
    def _send_raw(self, raw_bytes):
        if not self.sock:
            return
        try:
            self.sock.sendall(raw_bytes)
        except OSError:
            self.connected = False
            self.error_message = "Error al enviar datos al servidor."

    def send_input(self, move_x, move_y, shooting):
        """Envia la entrada actual del jugador local (una vez por tick
        de red, ver config.CLIENT_INPUT_SEND_RATE)."""
        payload = {"move_x": move_x, "move_y": move_y, "shooting": bool(shooting)}
        self._send_raw(encode_message(MSG_INPUT, payload))

    # ----------------- RECEPCION -----------------
    def poll_state(self):
        """Devuelve el snapshot de estado MAS RECIENTE recibido desde la
        ultima llamada (o None si no hay ninguno nuevo). Si llegaron
        varios mientras tanto, se descartan los antiguos: solo interesa
        el mas actual para dibujar el juego."""
        latest = None
        try:
            while True:
                latest = self.incoming_states.get_nowait()
        except queue.Empty:
            pass
        return latest

    # ----------------- CIERRE -----------------
    def disconnect(self):
        self._running = False
        self.connected = False
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock = None
