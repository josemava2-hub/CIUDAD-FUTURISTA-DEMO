"""
enemy.py
========
Enemigos alienigenas que persiguen al jugador.

Se define una clase base "Enemy" (alien normal) y varias subclases que
solo cambian algunos numeros (velocidad, vida, dano, color, tamano):

    - Enemy        -> alien normal (equilibrado)
    - FastAlien    -> rapido pero fragil
    - TankAlien    -> lento pero resistente
    - MiniBoss     -> mini-jefe, aparece cada X niveles
    - Boss         -> jefe final, aparece cada Y niveles

Anadir un enemigo nuevo es tan simple como crear otra subclase con sus
propios valores (y opcionalmente anadirla a ENEMY_CLASSES para que el
modo multijugador tambien pueda crearla a partir del tipo que envia el
servidor).
"""
import math

from kivy.uix.widget import Widget
from kivy.graphics import Color, Ellipse, Rectangle
from kivy.properties import NumericProperty, BooleanProperty

import config


class Enemy(Widget):
    health = NumericProperty(1)
    max_health = NumericProperty(1)
    is_alive = BooleanProperty(True)

    # -------- valores por defecto: alien normal --------
    ENEMY_TYPE = "alien"
    SPEED = config.ALIEN_SPEED
    MAX_HEALTH = config.ALIEN_HEALTH
    DAMAGE = config.ALIEN_DAMAGE
    COLOR = config.COLOR_ALIEN
    SIZE = (42, 42)
    COIN_REWARD = 1

    def __init__(self, x, y, **kwargs):
        super().__init__(**kwargs)
        self.size = self.SIZE
        self.size_hint = (None, None)
        self.pos = (x, y)
        self.max_health = self.MAX_HEALTH
        self.health = self.MAX_HEALTH
        self.contact_cooldown = 0.0

        self.bind(pos=self._redraw, size=self._redraw, health=self._redraw)
        self._redraw()

    # ------------------------------------------------------------
    # DIBUJO
    # ------------------------------------------------------------
    def _redraw(self, *args):
        self.canvas.clear()
        with self.canvas:
            Color(*self.COLOR)
            Ellipse(pos=self.pos, size=self.size)

            # Ojos (dan personalidad simple al enemigo)
            Color(0.05, 0.05, 0.08, 1)
            eye_size = max(4, self.width * 0.12)
            Ellipse(pos=(self.x + self.width * 0.28, self.y + self.height * 0.55),
                    size=(eye_size, eye_size))
            Ellipse(pos=(self.x + self.width * 0.62, self.y + self.height * 0.55),
                    size=(eye_size, eye_size))
        self._draw_health_bar()

    def _draw_health_bar(self):
        pct = max(0.0, self.health) / self.max_health if self.max_health else 0
        with self.canvas:
            Color(*config.COLOR_HEALTH_BG)
            Rectangle(pos=(self.x, self.y + self.height + 4), size=(self.width, 4))
            Color(*config.COLOR_HEALTH_FG)
            Rectangle(pos=(self.x, self.y + self.height + 4), size=(self.width * pct, 4))

    # ------------------------------------------------------------
    # LOGICA (solo se usa en modo un jugador; en multijugador el
    # servidor decide la posicion/vida y el cliente solo la refleja)
    # ------------------------------------------------------------
    def update(self, dt, target_x, target_y):
        if not self.is_alive:
            return
        dx = target_x - self.center_x
        dy = target_y - self.center_y
        dist = math.hypot(dx, dy)
        if dist > 1:
            self.x += (dx / dist) * self.SPEED * dt
            self.y += (dy / dist) * self.SPEED * dt
        if self.contact_cooldown > 0:
            self.contact_cooldown -= dt
        self._redraw()

    def take_damage(self, amount):
        """Devuelve True si el enemigo muere con este golpe."""
        if not self.is_alive:
            return False
        self.health -= amount
        if self.health <= 0:
            self.health = 0
            self.is_alive = False
            return True
        return False

    def can_deal_contact_damage(self):
        return self.contact_cooldown <= 0

    def register_contact(self):
        self.contact_cooldown = config.ENEMY_CONTACT_COOLDOWN


class FastAlien(Enemy):
    """Alien rapido: poca vida, mucha velocidad."""
    ENEMY_TYPE = "fast_alien"
    SPEED = config.FAST_ALIEN_SPEED
    MAX_HEALTH = config.FAST_ALIEN_HEALTH
    DAMAGE = config.FAST_ALIEN_DAMAGE
    COLOR = config.COLOR_FAST_ALIEN
    SIZE = (34, 34)
    COIN_REWARD = 1


class TankAlien(Enemy):
    """Alien tanque: lento pero muy resistente."""
    ENEMY_TYPE = "tank_alien"
    SPEED = config.TANK_ALIEN_SPEED
    MAX_HEALTH = config.TANK_ALIEN_HEALTH
    DAMAGE = config.TANK_ALIEN_DAMAGE
    COLOR = config.COLOR_TANK_ALIEN
    SIZE = (56, 56)
    COIN_REWARD = 2


class MiniBoss(Enemy):
    """Mini-jefe: aparece cada config.MINIBOSS_EVERY_N_LEVELS niveles."""
    ENEMY_TYPE = "miniboss"
    SPEED = config.MINIBOSS_SPEED
    MAX_HEALTH = config.MINIBOSS_HEALTH
    DAMAGE = config.MINIBOSS_DAMAGE
    COLOR = config.COLOR_MINIBOSS
    SIZE = (80, 80)
    COIN_REWARD = 8


class Boss(Enemy):
    """Jefe final: aparece cada config.BOSS_EVERY_N_LEVELS niveles."""
    ENEMY_TYPE = "boss"
    SPEED = config.BOSS_SPEED
    MAX_HEALTH = config.BOSS_HEALTH
    DAMAGE = config.BOSS_DAMAGE
    COLOR = config.COLOR_BOSS
    SIZE = (120, 120)
    COIN_REWARD = 25


# Usado por el modo multijugador para crear el widget correcto a partir
# del texto "type" que envia el servidor (ver server.py: ENEMY_STATS).
ENEMY_CLASSES = {
    "alien": Enemy,
    "fast_alien": FastAlien,
    "tank_alien": TankAlien,
    "miniboss": MiniBoss,
    "boss": Boss,
}
