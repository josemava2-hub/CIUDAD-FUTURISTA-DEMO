"""
bullet.py
=========
Proyectiles (disparos) del jugador.

En el modo un jugador, cada bala mueve sola (metodo update) y el propio
game_screen.py comprueba las colisiones contra los enemigos.

En el modo multijugador, el SERVIDOR es quien calcula el movimiento y
las colisiones de las balas; el cliente solo crea un Bullet "visual" y
actualiza su posicion con los datos que llegan del servidor (ver
game_screen.py -> _apply_network_state), sin llamar a update().
"""
from kivy.uix.widget import Widget
from kivy.graphics import Color, Ellipse

import config


class Bullet(Widget):
    def __init__(self, x, y, dir_x, dir_y, owner="player", damage=None, **kwargs):
        super().__init__(**kwargs)
        self.size = (10, 10)
        self.size_hint = (None, None)
        self.pos = (x, y)
        self.owner = owner  # "player" o "enemy" (por ahora solo se usa "player")

        length = (dir_x ** 2 + dir_y ** 2) ** 0.5 or 1
        self.dir_x = dir_x / length
        self.dir_y = dir_y / length

        self.speed = config.PLAYER_BULLET_SPEED
        self.damage = damage if damage is not None else config.PLAYER_BULLET_DAMAGE
        self.alive_time = 0.0
        self.max_alive_time = 2.5
        self.active = True

        self.bind(pos=self._redraw)
        self._redraw()

    def _redraw(self, *args):
        self.canvas.clear()
        color = config.COLOR_BULLET_PLAYER if self.owner == "player" else config.COLOR_BULLET_ENEMY
        with self.canvas:
            Color(*color)
            Ellipse(pos=self.pos, size=self.size)

    def update(self, dt):
        """Solo se usa en modo un jugador (fisica local)."""
        self.x += self.dir_x * self.speed * dt
        self.y += self.dir_y * self.speed * dt
        self.alive_time += dt

        if self.alive_time > self.max_alive_time:
            self.active = False
        if not (0 <= self.x <= config.WORLD_WIDTH and 0 <= self.y <= config.WORLD_HEIGHT):
            self.active = False
