"""
defeat_screen.py
================
Pantalla que se muestra cuando el jugador pierde toda su vida (en modo
un jugador) o cuando todos los jugadores mueren (en modo multijugador).

Muestra el nivel alcanzado y las monedas conseguidas, con botones para
reiniciar la partida o volver al menu principal.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.graphics import Color, Rectangle


class DefeatScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        with self.canvas.before:
            Color(0.14, 0.02, 0.02, 1)
            self._bg_rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_bg, size=self._update_bg)

        root = BoxLayout(orientation="vertical", padding=40, spacing=20)
        self.add_widget(root)

        root.add_widget(Label(text="[b]HAS SIDO DERROTADO[/b]", markup=True, font_size="30sp",
                               color=(0.9, 0.2, 0.2, 1), size_hint=(1, 0.3)))

        self.stats_label = Label(text="", font_size="18sp", size_hint=(1, 0.25))
        root.add_widget(self.stats_label)

        btn_restart = Button(text="REINICIAR", font_size="20sp", size_hint=(1, 0.15))
        btn_restart.bind(on_release=self._restart)
        root.add_widget(btn_restart)

        btn_menu = Button(text="MENU PRINCIPAL", font_size="16sp", size_hint=(1, 0.15))
        btn_menu.bind(on_release=self._go_menu)
        root.add_widget(btn_menu)

    def _update_bg(self, *args):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size

    def show_stats(self, level_reached, coins_earned):
        self.stats_label.text = (f"Nivel alcanzado: {level_reached}\n"
                                  f"Monedas conseguidas: {coins_earned}")

    def _restart(self, *args):
        game_screen = self.manager.get_screen("game")
        game_screen.start_singleplayer()
        self.manager.current = "game"

    def _go_menu(self, *args):
        self.manager.current = "menu"
