"""
protocol.py
===========
Define el protocolo de comunicacion entre "server.py" (servidor) y
"client.py" (cliente) para el modo multijugador.

Se usan sockets TCP normales (no WebSockets) para no depender de
librerias externas adicionales, lo que facilita mucho el empaquetado
para Android con Buildozer. El formato de cada mensaje es JSON de una
sola linea, terminado en "\n" (salto de linea). Esto se llama
"newline-delimited JSON" y es una forma simple y robusta de enviar
mensajes de tamano variable por un socket TCP (que en si mismo no
respeta los limites de cada "envio", solo entrega un flujo de bytes).

Este archivo NO depende de Kivy, por lo que puede usarse tanto en el
servidor (que puede correr sin interfaz grafica) como en el cliente.
"""
import json

# ---------------------------------------------------------------------
# TIPOS DE MENSAJE
# ---------------------------------------------------------------------
MSG_JOIN = "join"                # cliente -> servidor: quiero unirme
MSG_WELCOME = "welcome"          # servidor -> cliente: te asigno este id
MSG_INPUT = "input"              # cliente -> servidor: mi entrada actual
MSG_STATE = "state"              # servidor -> cliente: estado del mundo
MSG_PLAYER_LEFT = "player_left"  # servidor -> cliente: un jugador se fue
MSG_SERVER_FULL = "server_full"  # servidor -> cliente: no hay espacio


def encode_message(msg_type, payload=None):
    """Convierte un mensaje en bytes listos para enviar por el socket.

    Args:
        msg_type: uno de los MSG_* de arriba.
        payload: diccionario con datos adicionales (opcional).

    Returns:
        bytes: el mensaje en formato JSON + salto de linea, en UTF-8.
    """
    data = {"type": msg_type}
    if payload:
        data.update(payload)
    line = json.dumps(data, separators=(",", ":"))
    return (line + "\n").encode("utf-8")


def decode_message(raw_line):
    """Convierte una linea de bytes (sin el salto de linea final) en dict.

    Puede lanzar json.JSONDecodeError si el mensaje esta corrupto; quien
    llame a esta funcion debe estar preparado para ese caso si recibe
    datos de una fuente no confiable.
    """
    return json.loads(raw_line.decode("utf-8"))


class SocketLineReader:
    """Envuelve un socket para leer mensajes JSON delimitados por '\\n',
    incluso si TCP los entrega fragmentados, pegados entre si, o de a
    varios en un mismo paquete.

    Uso tipico (en un hilo dedicado a recibir datos):

        reader = SocketLineReader(sock)
        while True:
            for mensaje in reader.read_messages():
                procesar(mensaje)
    """

    def __init__(self, sock):
        self.sock = sock
        self.buffer = b""

    def read_messages(self):
        """Bloquea hasta recibir datos nuevos y produce (yield) todos los
        mensajes completos que se puedan armar con el buffer acumulado.

        Lanza ConnectionError si el otro extremo cerro la conexion, y
        OSError si hubo un problema de red. Quien llama a esta funcion
        debe capturar ambas excepciones para detectar la desconexion.
        """
        chunk = self.sock.recv(4096)
        if not chunk:
            raise ConnectionError("La conexion fue cerrada por el otro extremo")

        self.buffer += chunk
        while b"\n" in self.buffer:
            line, self.buffer = self.buffer.split(b"\n", 1)
            if not line.strip():
                continue
            try:
                yield decode_message(line)
            except (json.JSONDecodeError, UnicodeDecodeError):
                # Ignoramos mensajes corruptos en lugar de tirar abajo la
                # conexion completa; simplemente se pierde ese mensaje.
                continue
