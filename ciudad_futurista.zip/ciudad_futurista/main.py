"""
main.py
=======
Punto de entrada de "Ciudad Futurista".

Ejecutar en PC (Windows/Linux/macOS) con:

    python main.py

El mismo codigo, sin ningun cambio, se empaqueta para Android con
Buildozer (ver buildozer.spec y el README.md para las instrucciones
completas). La deteccion de plataforma (teclado vs. controles tactiles,
tamano de ventana, etc.) es automatica gracias a "kivy.utils.platform".
"""
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, FadeTransition
from kivy.core.window import Window
from kivy.utils import platform

import config
from menu_screen import MenuScreen
from game_screen import GameScreen
from shop_screen import ShopScreen
from defeat_screen import DefeatScreen
from multiplayer_screen import MultiplayerScreen

# En PC fijamos un tamano de ventana comodo para probar el juego. En
# Android, la ventana siempre ocupa toda la pantalla del dispositivo,
# asi que no hace falta (ni se puede) fijar un tamano.
if platform not in ("android", "ios"):
    Window.size = (config.WINDOW_WIDTH, config.WINDOW_HEIGHT)


class CiudadFuturistaApp(App):
    title = "Ciudad Futurista"

    def build(self):
        sm = ScreenManager(transition=FadeTransition(duration=0.15))
        sm.add_widget(MenuScreen(name="menu"))
        sm.add_widget(GameScreen(name="game"))
        sm.add_widget(ShopScreen(name="shop"))
        sm.add_widget(DefeatScreen(name="defeat"))
        sm.add_widget(MultiplayerScreen(name="multiplayer"))
        sm.current = "menu"
        return sm

    def on_stop(self):
        """Cierra de forma ordenada las conexiones de red y el servidor
        local (si se llego a crear uno) al salir de la aplicacion."""
        game_screen = self.root.get_screen("game")
        if game_screen.network_client is not None:
            game_screen.network_client.disconnect()

        multiplayer_screen = self.root.get_screen("multiplayer")
        multiplayer_screen.stop_hosted_server()


if __name__ == "__main__":
    CiudadFuturistaApp().run()
