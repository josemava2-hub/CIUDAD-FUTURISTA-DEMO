"""
level_manager.py
=================
Controla la progresion de niveles en el modo UN JUGADOR: cuantos
enemigos aparecen en cada nivel, cuando toca un mini-jefe o un jefe, y
cuando se considera que el nivel esta completo.

(En el modo multijugador, esta misma logica existe de forma
independiente dentro de server.py, ya que el servidor debe poder
ejecutarse sin Kivy. Se mantienen separadas a proposito para que cada
una sea simple y no dependa de la otra; si cambias el balance del
juego en config.py, ambas lo respetaran automaticamente).
"""
import random

import config
from enemy import Enemy, FastAlien, TankAlien, MiniBoss, Boss


class LevelManager:
    def __init__(self):
        self.level = 1
        self.enemies_remaining_to_spawn = 0
        self.pending_boss = None
        self.level_cleared = False
        self._spawn_timer = 0.0
        self._start_level(self.level)

    def _start_level(self, level):
        self.level = level
        self.level_cleared = False
        self.enemies_remaining_to_spawn = (config.ENEMIES_PER_LEVEL_BASE +
                                            (level - 1) * config.ENEMIES_PER_LEVEL_INCREMENT)
        self._spawn_timer = 0.0
        self.pending_boss = None
        if level % config.BOSS_EVERY_N_LEVELS == 0:
            self.pending_boss = Boss
        elif level % config.MINIBOSS_EVERY_N_LEVELS == 0:
            self.pending_boss = MiniBoss

    def _random_enemy_class(self):
        roll = random.random()
        if roll < 0.55:
            return Enemy
        elif roll < 0.8:
            return FastAlien
        return TankAlien

    def update(self, dt, active_enemy_count):
        """Debe llamarse una vez por fotograma. Devuelve la CLASE de un
        enemigo a spawnear en este instante, o None si todavia no toca
        que aparezca ninguno."""
        to_spawn = None

        if self.enemies_remaining_to_spawn > 0:
            self._spawn_timer -= dt
            if self._spawn_timer <= 0:
                self._spawn_timer = config.ENEMY_SPAWN_INTERVAL
                to_spawn = self._random_enemy_class()
                self.enemies_remaining_to_spawn -= 1
        elif self.pending_boss is not None and active_enemy_count == 0:
            to_spawn = self.pending_boss
            self.pending_boss = None

        if (self.enemies_remaining_to_spawn == 0 and self.pending_boss is None
                and active_enemy_count == 0 and not self.level_cleared):
            self.level_cleared = True

        return to_spawn

    def advance_level(self):
        self._start_level(self.level + 1)

    def get_level(self):
        return self.level
