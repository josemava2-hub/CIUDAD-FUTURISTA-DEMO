"""
shop_screen.py
==============
Tienda donde el jugador gasta las monedas acumuladas (guardadas entre
partidas, ver save_data.py) en mejoras permanentes para el modo un
jugador: velocidad, dano de disparo y vida maxima.

Nota: en el modo multijugador actual, las mejoras de la tienda todavia
no se envian al servidor (el servidor siempre usa los valores base de
config.py para todos los jugadores). Es un buen punto de partida para
ampliar el juego: bastaria con incluir el nivel de cada mejora en el
mensaje "join" (ver protocol.py y server.py) y aplicarlo al crear el
ServerPlayer correspondiente.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.graphics import Color, Rectangle

import config
from save_data import load_data, save_data

UPGRADE_LABELS = {
    "speed": "Velocidad",
    "damage": "Dano de disparo",
    "max_health": "Vida maxima",
}


class ShopScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        with self.canvas.before:
            Color(*config.COLOR_SKY_DARK)
            self._bg_rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_bg, size=self._update_bg)

        self.root_layout = BoxLayout(orientation="vertical", padding=30, spacing=14)
        self.add_widget(self.root_layout)

        self.root_layout.add_widget(Label(text="[b]TIENDA[/b]", markup=True, font_size="28sp",
                                           size_hint=(1, 0.15)))

        self.coins_label = Label(text="Monedas: 0", font_size="20sp", size_hint=(1, 0.12))
        self.root_layout.add_widget(self.coins_label)

        self._upgrade_rows = {}
        for key in ("speed", "damage", "max_health"):
            row = BoxLayout(orientation="horizontal", size_hint=(1, 0.15), spacing=10)
            label = Label(text=UPGRADE_LABELS[key], font_size="16sp", size_hint=(0.5, 1))
            btn = Button(text="Mejorar", size_hint=(0.5, 1))
            btn.bind(on_release=lambda inst, k=key: self._buy_upgrade(k))
            row.add_widget(label)
            row.add_widget(btn)
            self.root_layout.add_widget(row)
            self._upgrade_rows[key] = (label, btn)

        btn_back = Button(text="VOLVER AL MENU", font_size="18sp", size_hint=(1, 0.15))
        btn_back.bind(on_release=self._go_back)
        self.root_layout.add_widget(btn_back)

    def _update_bg(self, *args):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size

    def on_pre_enter(self, *args):
        self.refresh()

    def refresh(self):
        data = load_data()
        self.coins_label.text = f"Monedas: {data['total_coins']}"

        for key, (label, btn) in self._upgrade_rows.items():
            level = data["upgrades"].get(key, 0)
            cost = config.UPGRADE_COSTS[key]
            label.text = f"{UPGRADE_LABELS[key]} (Nivel {level}/{config.UPGRADE_MAX_LEVEL})"
            if level >= config.UPGRADE_MAX_LEVEL:
                btn.text = "NIVEL MAXIMO"
                btn.disabled = True
            else:
                btn.text = f"Mejorar ({cost} monedas)"
                btn.disabled = data["total_coins"] < cost

    def _buy_upgrade(self, key):
        data = load_data()
        cost = config.UPGRADE_COSTS[key]
        level = data["upgrades"].get(key, 0)
        if data["total_coins"] >= cost and level < config.UPGRADE_MAX_LEVEL:
            data["total_coins"] -= cost
            data["upgrades"][key] = level + 1
            save_data(data)
        self.refresh()

    def _go_back(self, *args):
        self.manager.current = "menu"
