"""
menu_screen.py
==============
Pantalla de menu principal del juego.

Botones:
    - JUGAR: inicia una partida de un jugador.
    - MULTIJUGADOR: va a la pantalla para crear/unirse a una partida en red.
    - TIENDA: va a la pantalla de mejoras.
    - SALIR: cierra la aplicacion.
"""
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.graphics import Color, Rectangle

import config


class MenuScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        with self.canvas.before:
            Color(*config.COLOR_SKY_DARK)
            self._bg_rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_bg, size=self._update_bg)

        root = BoxLayout(orientation="vertical", padding=40, spacing=16)
        self.add_widget(root)

        root.add_widget(Label(text="[b]CIUDAD FUTURISTA[/b]", markup=True, font_size="40sp",
                               size_hint=(1, 0.28), color=(0.2, 0.9, 1, 1)))
        root.add_widget(Label(text="Defiende la ciudad de la invasion alienigena",
                               font_size="15sp", size_hint=(1, 0.1),
                               color=(0.8, 0.8, 0.85, 1)))

        btn_play = Button(text="JUGAR", font_size="22sp", size_hint=(1, 0.14))
        btn_play.bind(on_release=self._go_play)
        root.add_widget(btn_play)

        btn_multiplayer = Button(text="MULTIJUGADOR", font_size="18sp", size_hint=(1, 0.13))
        btn_multiplayer.bind(on_release=self._go_multiplayer)
        root.add_widget(btn_multiplayer)

        btn_shop = Button(text="TIENDA", font_size="18sp", size_hint=(1, 0.13))
        btn_shop.bind(on_release=self._go_shop)
        root.add_widget(btn_shop)

        btn_exit = Button(text="SALIR", font_size="18sp", size_hint=(1, 0.13))
        btn_exit.bind(on_release=self._exit_app)
        root.add_widget(btn_exit)

    def _update_bg(self, *args):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size

    def _go_play(self, *args):
        game_screen = self.manager.get_screen("game")
        game_screen.start_singleplayer()
        self.manager.current = "game"

    def _go_multiplayer(self, *args):
        self.manager.current = "multiplayer"

    def _go_shop(self, *args):
        self.manager.current = "shop"

    def _exit_app(self, *args):
        from kivy.app import App
        App.get_running_app().stop()
