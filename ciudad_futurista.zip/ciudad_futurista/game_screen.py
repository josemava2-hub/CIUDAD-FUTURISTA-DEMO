"""
game_screen.py
==============
Pantalla principal donde ocurre la partida. Cumple dos papeles segun el
modo elegido en el menu:

    - MODO UN JUGADOR ("single"): toda la logica del juego (movimiento,
      enemigos persiguiendo, colisiones, disparos, monedas, niveles)
      corre aqui mismo, en el cliente, usando LevelManager, Enemy,
      Bullet y Coin directamente.

    - MODO MULTIJUGADOR ("multiplayer"): el SERVIDOR (server.py) es
      quien decide todo (posiciones, vidas, enemigos, monedas, disparos,
      nivel). Esta pantalla solo envia la entrada local (hacia donde te
      mueves, si disparas) y refleja en pantalla el estado que recibe
      del servidor a traves de client.py. Esto evita que dos jugadores
      vean partidas distintas (desincronizacion).

La "camara 2D" se implementa moviendo un Widget contenedor llamado
"self.world" (que incluye el mapa, el/los jugador/es, enemigos, balas y
monedas) en sentido opuesto al jugador local, para que este quede mas o
menos centrado en la pantalla mientras la ciudad se desplaza alrededor.
"""
import math
import random

from kivy.uix.screenmanager import Screen
from kivy.uix.widget import Widget
from kivy.clock import Clock

import config
from input_manager import InputManager
from player import Player
from enemy import ENEMY_CLASSES
from bullet import Bullet
from coin import Coin
from city_map import CityMap
from level_manager import LevelManager
from ui import HUD, TouchDPad, ShootButton, is_mobile_device
from save_data import load_data, save_data
from client import NetworkClient


class GameScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.mode = "single"  # "single" o "multiplayer"
        self.input_manager = InputManager()

        # ---- Contenedor del "mundo" (todo lo que se mueve con la camara) ----
        self.world = Widget(size=(config.WORLD_WIDTH, config.WORLD_HEIGHT),
                             size_hint=(None, None), pos=(0, 0))
        self.add_widget(self.world)

        self.city_map = CityMap()
        self.world.add_widget(self.city_map)

        # ---- HUD (fijo en pantalla, no se mueve con la camara) ----
        self.hud = HUD()
        self.add_widget(self.hud)

        # ---- Controles tactiles (solo se anaden en Android/iOS) ----
        self.touch_controls_visible = is_mobile_device()
        self.dpad = TouchDPad(self.input_manager, pos=(20, 20))
        self.shoot_button = ShootButton(self.input_manager)
        if self.touch_controls_visible:
            self.add_widget(self.dpad)
            self.add_widget(self.shoot_button)

        self.bind(size=self._layout_overlay, pos=self._layout_overlay)

        # ---- Estado compartido ----
        self.local_player = None
        self.network_client = None
        self._update_event = None
        self._game_over_triggered = False

        # ---- Estado especifico del modo UN JUGADOR ----
        self.level_manager = None
        self.sp_enemies = []
        self.bullets = []
        self.coins_widgets = []

        # ---- Estado especifico del modo MULTIJUGADOR ----
        self.remote_players = {}     # id -> Player
        self.network_enemies = {}    # id -> Enemy
        self.network_coins = {}      # id -> Coin
        self.network_bullets = {}    # id -> Bullet
        self._network_send_timer = 0.0

        self._layout_overlay()

    # ------------------------------------------------------------
    # DISTRIBUCION DE LA INTERFAZ (HUD y controles siempre fijos)
    # ------------------------------------------------------------
    def _layout_overlay(self, *args):
        self.hud.width = self.width
        self.hud.top = self.top
        self.hud.x = self.x
        self.shoot_button.pos = (self.right - 110, self.y + 20)
        self.dpad.pos = (self.x + 20, self.y + 20)

    # ------------------------------------------------------------
    # MODO UN JUGADOR
    # ------------------------------------------------------------
    def start_singleplayer(self):
        self._reset_world()
        self.mode = "single"

        data = load_data()
        self._session_coins_at_start = data.get("total_coins", 0)

        self.local_player = Player(controlled_locally=True)
        self._apply_upgrades(self.local_player, data.get("upgrades", {}))
        self.local_player.pos = (100, 100)
        self.world.add_widget(self.local_player)

        self.level_manager = LevelManager()
        self._game_over_triggered = False

        self._start_update_loop()

    def _apply_upgrades(self, player, upgrades):
        speed_lv = upgrades.get("speed", 0)
        dmg_lv = upgrades.get("damage", 0)
        hp_lv = upgrades.get("max_health", 0)
        player.max_health = config.PLAYER_MAX_HEALTH + hp_lv * config.UPGRADE_HEALTH_BONUS_PER_LEVEL
        player.health = player.max_health
        player.bonus_speed = speed_lv * config.UPGRADE_SPEED_BONUS_PER_LEVEL
        player.bonus_damage = dmg_lv * config.UPGRADE_DAMAGE_BONUS_PER_LEVEL

    # ------------------------------------------------------------
    # MODO MULTIJUGADOR
    # ------------------------------------------------------------
    def start_multiplayer(self, host, port, player_name):
        self._reset_world()
        self.mode = "multiplayer"

        self.network_client = NetworkClient()
        connected = self.network_client.connect(host, port, player_name)
        if not connected:
            return False

        self._game_over_triggered = False
        self._start_update_loop()
        return True

    # ------------------------------------------------------------
    # LIMPIEZA / REINICIO
    # ------------------------------------------------------------
    def _reset_world(self):
        if self._update_event is not None:
            self._update_event.cancel()
            self._update_event = None

        if self.network_client is not None:
            self.network_client.disconnect()
            self.network_client = None

        for widget in list(self.world.children):
            if widget is not self.city_map:
                self.world.remove_widget(widget)

        self.input_manager.reset()

        self.local_player = None
        self.level_manager = None
        self.sp_enemies = []
        self.bullets = []
        self.coins_widgets = []

        self.remote_players = {}
        self.network_enemies = {}
        self.network_coins = {}
        self.network_bullets = {}
        self._network_send_timer = 0.0

        self.world.x = self.x
        self.world.y = self.y

    def _start_update_loop(self):
        self._update_event = Clock.schedule_interval(self.update, 1 / 60)

    # ------------------------------------------------------------
    # BUCLE PRINCIPAL
    # ------------------------------------------------------------
    def update(self, dt):
        if self.mode == "single":
            self._update_singleplayer(dt)
        else:
            self._update_multiplayer(dt)
        self._update_camera()

    # ==============================================================
    # ---------------------- UN JUGADOR ---------------------------
    # ==============================================================
    def _update_singleplayer(self, dt):
        player = self.local_player
        if player is None:
            return

        if player.is_alive:
            mx, my = self.input_manager.get_movement_vector()
            player.update(dt, mx, my)

            if self.input_manager.is_shooting() and player.can_shoot():
                self._spawn_bullet_singleplayer()

        self._update_enemies_singleplayer(dt, player)
        self._update_bullets_singleplayer(dt)
        self._update_coin_pickups_singleplayer(player)
        self._update_level_singleplayer(dt)

        level = self.level_manager.get_level() if self.level_manager else 1
        self.hud.update_stats(player.health, player.max_health, player.coins, level)

        if not player.is_alive and not self._game_over_triggered:
            self._trigger_defeat_singleplayer()

    def _spawn_bullet_singleplayer(self):
        player = self.local_player
        player.register_shot()
        dir_x, dir_y = player.last_move_dir
        bullet = Bullet(player.center_x, player.center_y, dir_x, dir_y, owner="player",
                         damage=config.PLAYER_BULLET_DAMAGE + player.bonus_damage)
        self.bullets.append(bullet)
        self.world.add_widget(bullet)

    def _update_enemies_singleplayer(self, dt, player):
        for enemy in list(self.sp_enemies):
            if player.is_alive:
                enemy.update(dt, player.center_x, player.center_y)
                if enemy.can_deal_contact_damage():
                    dist = math.hypot(enemy.center_x - player.center_x,
                                       enemy.center_y - player.center_y)
                    if dist < enemy.width / 2 + 24:
                        player.take_damage(enemy.DAMAGE)
                        enemy.register_contact()

    def _update_bullets_singleplayer(self, dt):
        for bullet in list(self.bullets):
            bullet.update(dt)
            if not bullet.active:
                self._remove_bullet(bullet)
                continue

            for enemy in list(self.sp_enemies):
                if not enemy.is_alive:
                    continue
                dist = math.hypot(bullet.center_x - enemy.center_x,
                                   bullet.center_y - enemy.center_y)
                if dist < enemy.width / 2 + 6:
                    killed = enemy.take_damage(bullet.damage)
                    self._remove_bullet(bullet)
                    if killed:
                        self._on_enemy_killed_singleplayer(enemy)
                    break

    def _update_coin_pickups_singleplayer(self, player):
        for coin in list(self.coins_widgets):
            dist = math.hypot(coin.center_x - player.center_x, coin.center_y - player.center_y)
            if dist < config.COIN_PICKUP_RADIUS:
                player.add_coins(coin.value)
                self._remove_coin(coin)

    def _update_level_singleplayer(self, dt):
        if self.level_manager is None:
            return
        enemy_cls = self.level_manager.update(dt, len(self.sp_enemies))
        if enemy_cls:
            self._spawn_enemy_singleplayer(enemy_cls)
        if self.level_manager.level_cleared:
            self.level_manager.advance_level()

    def _spawn_enemy_singleplayer(self, enemy_cls):
        side = random.choice(["left", "right"])
        x = 10 if side == "left" else config.WORLD_WIDTH - 60
        y = random.uniform(70, config.WORLD_HEIGHT - 60)
        enemy = enemy_cls(x, y)
        self.sp_enemies.append(enemy)
        self.world.add_widget(enemy)

    def _on_enemy_killed_singleplayer(self, enemy):
        self.sp_enemies.remove(enemy)
        self.world.remove_widget(enemy)

        should_drop = enemy.ENEMY_TYPE in ("miniboss", "boss") or random.random() < config.COIN_DROP_CHANCE
        if should_drop:
            multiplier = 8 if enemy.ENEMY_TYPE == "boss" else 3 if enemy.ENEMY_TYPE == "miniboss" else 1
            coin = Coin(enemy.center_x, enemy.center_y, config.COIN_VALUE * multiplier)
            self.coins_widgets.append(coin)
            self.world.add_widget(coin)

    def _trigger_defeat_singleplayer(self):
        self._game_over_triggered = True
        player = self.local_player

        data = load_data()
        data["total_coins"] = data.get("total_coins", 0) + player.coins
        data["max_level_reached"] = max(data.get("max_level_reached", 1),
                                         self.level_manager.get_level())
        save_data(data)

        defeat_screen = self.manager.get_screen("defeat")
        defeat_screen.show_stats(self.level_manager.get_level(), player.coins)
        Clock.schedule_once(lambda dt: self._go_to_defeat(), 0.6)

    # ==============================================================
    # ---------------------- MULTIJUGADOR --------------------------
    # ==============================================================
    def _update_multiplayer(self, dt):
        client = self.network_client
        if client is None:
            return

        if not client.connected:
            self._handle_network_error(client.error_message or "Conexion perdida")
            return

        self._network_send_timer -= dt
        if self._network_send_timer <= 0:
            self._network_send_timer = 1.0 / config.CLIENT_INPUT_SEND_RATE
            mx, my = self.input_manager.get_movement_vector()
            client.send_input(mx, my, self.input_manager.is_shooting())

        if client.player_id is None:
            return  # esperando el mensaje de bienvenida del servidor

        state = client.poll_state()
        if state:
            self._apply_network_state(state)

    def _ensure_player_widget(self, player_id, is_local):
        if is_local:
            if self.local_player is None:
                self.local_player = Player(controlled_locally=True)
                self.world.add_widget(self.local_player)
            return self.local_player

        if player_id not in self.remote_players:
            widget = Player(controlled_locally=False)
            self.remote_players[player_id] = widget
            self.world.add_widget(widget)
        return self.remote_players[player_id]

    def _apply_network_state(self, state):
        local_id = self.network_client.player_id

        # ---- Jugadores ----
        seen_player_ids = set()
        local_data = None
        for p in state.get("players", []):
            seen_player_ids.add(p["id"])
            is_local = (p["id"] == local_id)
            if is_local:
                local_data = p
            widget = self._ensure_player_widget(p["id"], is_local)
            widget.set_network_state(p["x"], p["y"], p["health"], p["coins"], p["facing_x"])
            widget.player_name = p.get("name", "")

        for pid in list(self.remote_players.keys()):
            if pid not in seen_player_ids:
                self.world.remove_widget(self.remote_players[pid])
                del self.remote_players[pid]

        # ---- Enemigos ----
        seen_enemy_ids = set()
        for e in state.get("enemies", []):
            seen_enemy_ids.add(e["id"])
            if e["id"] not in self.network_enemies:
                enemy_cls = ENEMY_CLASSES.get(e["type"], ENEMY_CLASSES["alien"])
                widget = enemy_cls(e["x"], e["y"])
                self.network_enemies[e["id"]] = widget
                self.world.add_widget(widget)
            widget = self.network_enemies[e["id"]]
            widget.max_health = e["max_health"]
            widget.health = e["health"]
            widget.pos = (e["x"], e["y"])

        for eid in list(self.network_enemies.keys()):
            if eid not in seen_enemy_ids:
                self.world.remove_widget(self.network_enemies[eid])
                del self.network_enemies[eid]

        # ---- Monedas ----
        seen_coin_ids = set()
        for c in state.get("coins", []):
            seen_coin_ids.add(c["id"])
            if c["id"] not in self.network_coins:
                coin = Coin(c["x"], c["y"])
                self.network_coins[c["id"]] = coin
                self.world.add_widget(coin)
            self.network_coins[c["id"]].pos = (c["x"], c["y"])

        for cid in list(self.network_coins.keys()):
            if cid not in seen_coin_ids:
                self.world.remove_widget(self.network_coins[cid])
                del self.network_coins[cid]

        # ---- Balas (disparos) ----
        seen_bullet_ids = set()
        for b in state.get("bullets", []):
            seen_bullet_ids.add(b["id"])
            if b["id"] not in self.network_bullets:
                bullet = Bullet(b["x"], b["y"], 1, 0, owner="player")
                self.network_bullets[b["id"]] = bullet
                self.world.add_widget(bullet)
            self.network_bullets[b["id"]].pos = (b["x"], b["y"])

        for bid in list(self.network_bullets.keys()):
            if bid not in seen_bullet_ids:
                self.world.remove_widget(self.network_bullets[bid])
                del self.network_bullets[bid]

        # ---- HUD ----
        if local_data:
            self.hud.update_stats(local_data["health"], local_data["max_health"],
                                   local_data["coins"], state.get("level", 1))

        # ---- Fin de la partida ----
        if state.get("game_over") and not self._game_over_triggered:
            self._game_over_triggered = True
            coins = local_data["coins"] if local_data else 0
            defeat_screen = self.manager.get_screen("defeat")
            defeat_screen.show_stats(state.get("level", 1), coins)
            Clock.schedule_once(lambda dt: self._go_to_defeat(), 0.6)

    def _handle_network_error(self, message):
        if self._game_over_triggered:
            return
        self._game_over_triggered = True
        print(f"[Cliente] {message}")
        Clock.schedule_once(lambda dt: self._go_to_menu_after_error(), 0.4)

    def _go_to_menu_after_error(self):
        if self._update_event is not None:
            self._update_event.cancel()
            self._update_event = None
        self.manager.current = "menu"

    # ------------------------------------------------------------
    # UTILIDADES COMUNES
    # ------------------------------------------------------------
    def _remove_bullet(self, bullet):
        if bullet in self.bullets:
            self.bullets.remove(bullet)
        if bullet.parent is not None:
            self.world.remove_widget(bullet)

    def _remove_coin(self, coin):
        if coin in self.coins_widgets:
            self.coins_widgets.remove(coin)
        if coin.parent is not None:
            self.world.remove_widget(coin)

    def _update_camera(self):
        player = self.local_player
        if player is None:
            return
        target_x = player.center_x - self.width / 2
        max_x = max(0, config.WORLD_WIDTH - self.width)
        target_x = max(0, min(target_x, max_x))
        self.world.x = self.x - target_x
        self.world.y = self.y

    def _go_to_defeat(self):
        if self._update_event is not None:
            self._update_event.cancel()
            self._update_event = None
        if self.network_client is not None:
            self.network_client.disconnect()
        self.manager.current = "defeat"
