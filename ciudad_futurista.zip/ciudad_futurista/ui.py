"""
ui.py
=====
Elementos de interfaz que se muestran DURANTE la partida:

    - HUD: barra superior con vida, monedas y nivel actual.
    - TouchDPad: cruceta tactil de 4 direcciones para moverse en Android.
    - ShootButton: boton tactil circular para disparar (mantener pulsado
      dispara de forma continua, igual que mantener ESPACIO en PC).

Los controles tactiles se muestran automaticamente SOLO en dispositivos
moviles (ver "is_mobile_device" y su uso en game_screen.py); en PC no
aparecen en pantalla y en su lugar se usa el teclado.
"""
from kivy.uix.widget import Widget
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.graphics import Color, Ellipse, Rectangle
from kivy.utils import platform

import config


def is_mobile_device():
    """Devuelve True si el juego se esta ejecutando en Android o iOS."""
    return platform in ("android", "ios")


# ======================================================================
# HUD (vida, monedas, nivel)
# ======================================================================
class HUD(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="horizontal", size_hint=(1, None), height=44,
                          padding=(10, 8), **kwargs)
        with self.canvas.before:
            Color(0, 0, 0, 0.35)
            self._bg_rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_bg, size=self._update_bg)

        self.health_label = Label(text="Vida: 100/100", size_hint=(0.4, 1),
                                   halign="left", valign="middle")
        self.coins_label = Label(text="Monedas: 0", size_hint=(0.3, 1))
        self.level_label = Label(text="Nivel: 1", size_hint=(0.3, 1))

        for label in (self.health_label, self.coins_label, self.level_label):
            label.bind(size=lambda inst, val: setattr(inst, "text_size", val))

        self.add_widget(self.health_label)
        self.add_widget(self.coins_label)
        self.add_widget(self.level_label)

    def _update_bg(self, *args):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size

    def update_stats(self, health, max_health, coins, level):
        self.health_label.text = f"Vida: {int(max(0, health))}/{int(max_health)}"
        self.coins_label.text = f"Monedas: {int(coins)}"
        self.level_label.text = f"Nivel: {level}"


# ======================================================================
# CONTROLES TACTILES: CRUCETA DE MOVIMIENTO
# ======================================================================
class _DirectionButton(Widget):
    """Boton circular individual usado dentro de TouchDPad. Puede
    recibir varios toques a la vez en distintos botones (para permitir
    movimiento en diagonal, por ejemplo arriba + derecha)."""

    def __init__(self, direction, input_manager, **kwargs):
        super().__init__(**kwargs)
        self.direction = direction
        self.input_manager = input_manager
        self.size_hint = (None, None)
        self._touch_id = None
        self._pressed = False

        self.bind(pos=self._redraw, size=self._redraw)
        self._redraw()

    def _redraw(self, *args):
        self.canvas.clear()
        alpha = 0.45 if self._pressed else 0.20
        with self.canvas:
            Color(1, 1, 1, alpha)
            Ellipse(pos=self.pos, size=self.size)

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            self._touch_id = touch.uid
            self._pressed = True
            self.input_manager.press(self.direction)
            self._redraw()
            return True
        return False

    def on_touch_move(self, touch):
        # Si el dedo se desliza fuera del boton, se suelta la direccion.
        if touch.uid == self._touch_id and not self.collide_point(*touch.pos):
            self._release(touch)
        return False

    def on_touch_up(self, touch):
        if touch.uid == self._touch_id:
            self._release(touch)
            return True
        return False

    def _release(self, touch):
        self._touch_id = None
        self._pressed = False
        self.input_manager.release(self.direction)
        self._redraw()


class TouchDPad(Widget):
    """Cruceta tactil (arriba/abajo/izquierda/derecha)."""

    def __init__(self, input_manager, **kwargs):
        super().__init__(**kwargs)
        self.input_manager = input_manager
        self.size = (180, 180)
        self.size_hint = (None, None)

        btn_size = (58, 58)
        self.btn_up = _DirectionButton("up", input_manager, size=btn_size)
        self.btn_down = _DirectionButton("down", input_manager, size=btn_size)
        self.btn_left = _DirectionButton("left", input_manager, size=btn_size)
        self.btn_right = _DirectionButton("right", input_manager, size=btn_size)

        for btn in (self.btn_up, self.btn_down, self.btn_left, self.btn_right):
            self.add_widget(btn)

        self.bind(pos=self._layout_buttons, size=self._layout_buttons)
        self._layout_buttons()

    def _layout_buttons(self, *args):
        cx = self.x + self.width / 2
        cy = self.y + self.height / 2
        gap = 56
        half = 29  # mitad del tamano del boton (58 / 2)
        self.btn_up.pos = (cx - half, cy + gap - half)
        self.btn_down.pos = (cx - half, cy - gap - half)
        self.btn_left.pos = (cx - gap - half, cy - half)
        self.btn_right.pos = (cx + gap - half, cy - half)


# ======================================================================
# CONTROLES TACTILES: BOTON DE DISPARO
# ======================================================================
class ShootButton(Widget):
    """Boton tactil circular: mantener pulsado dispara sin parar."""

    def __init__(self, input_manager, **kwargs):
        super().__init__(**kwargs)
        self.input_manager = input_manager
        self.size = (86, 86)
        self.size_hint = (None, None)
        self._touch_id = None
        self._pressed = False

        self.bind(pos=self._redraw, size=self._redraw)
        self._redraw()

    def _redraw(self, *args):
        self.canvas.clear()
        alpha = 0.75 if self._pressed else 0.5
        with self.canvas:
            Color(0.90, 0.20, 0.20, alpha)
            Ellipse(pos=self.pos, size=self.size)
            Color(1, 1, 1, 0.85)
            cx = self.x + self.width / 2
            cy = self.y + self.height / 2
            Ellipse(pos=(cx - 6, cy - 6), size=(12, 12))

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            self._touch_id = touch.uid
            self._pressed = True
            self.input_manager.set_shooting(True)
            self._redraw()
            return True
        return False

    def on_touch_up(self, touch):
        if touch.uid == self._touch_id:
            self._touch_id = None
            self._pressed = False
            self.input_manager.set_shooting(False)
            self._redraw()
            return True
        return False
