"""
save_data.py
============
Guarda y carga el progreso del jugador (monedas totales acumuladas,
mejoras compradas en la tienda, nivel maximo alcanzado) en un archivo
JSON.

Se usa "App.user_data_dir" de Kivy para elegir donde guardar el
archivo: esta ruta funciona automaticamente tanto en Windows como en
Android (en Android apunta a la carpeta privada de datos de la app, que
es el lugar correcto para guardar partidas).
"""
import json
import os

try:
    from kivy.app import App
    _HAS_KIVY = True
except ImportError:
    _HAS_KIVY = False

SAVE_FILE_NAME = "ciudad_futurista_save.json"

DEFAULT_DATA = {
    "total_coins": 0,
    "max_level_reached": 1,
    "upgrades": {
        "speed": 0,
        "damage": 0,
        "max_health": 0,
    },
}


def _get_save_path():
    if _HAS_KIVY:
        app = App.get_running_app()
        if app is not None:
            folder = app.user_data_dir
            os.makedirs(folder, exist_ok=True)
            return os.path.join(folder, SAVE_FILE_NAME)
    # Alternativa si no hay ninguna app de Kivy corriendo todavia
    # (por ejemplo, al probar este archivo de forma aislada).
    fallback_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(fallback_dir, SAVE_FILE_NAME)


def load_data():
    path = _get_save_path()
    if not os.path.exists(path):
        return json.loads(json.dumps(DEFAULT_DATA))  # copia profunda simple

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return json.loads(json.dumps(DEFAULT_DATA))

    merged = json.loads(json.dumps(DEFAULT_DATA))
    merged.update(data)
    if "upgrades" in data and isinstance(data["upgrades"], dict):
        merged["upgrades"].update(data["upgrades"])
    return merged


def save_data(data):
    path = _get_save_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass
