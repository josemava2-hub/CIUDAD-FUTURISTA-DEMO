"""
player.py
=========
Define al jugador: un robot controlable, con vida, barra de vida,
animacion simple (piernas que se mueven al caminar) y capacidad de
disparar.

El robot se dibuja con formas basicas de Kivy (Rectangle, Ellipse) en
lugar de imagenes externas. Esto tiene dos ventajas para este proyecto:
    1) No dependemos de archivos de imagen que haya que empaquetar y
       que podrian faltar o dar error al compilar para Android.
    2) Es muy facil de modificar: cambia los colores en config.py o los
       tamanos/formas aqui mismo, sin necesidad de un editor de imagenes.

Si mas adelante quieres usar sprites/imagenes reales, el lugar natural
para hacerlo es dentro de "_redraw()", reemplazando las figuras por un
"kivy.graphics.Rectangle" con "texture=mi_imagen.texture".
"""
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle, Ellipse
from kivy.properties import NumericProperty, BooleanProperty, StringProperty

import config


class Player(Widget):
    health = NumericProperty(config.PLAYER_MAX_HEALTH)
    max_health = NumericProperty(config.PLAYER_MAX_HEALTH)
    coins = NumericProperty(0)
    facing_x = NumericProperty(1)     # 1 = mirando a la derecha, -1 = izquierda
    is_alive = BooleanProperty(True)
    player_name = StringProperty("Jugador")

    def __init__(self, controlled_locally=True, **kwargs):
        super().__init__(**kwargs)
        self.size = config.PLAYER_SIZE
        self.size_hint = (None, None)
        self.controlled_locally = controlled_locally

        # Mejoras compradas en la tienda (ver shop_screen.py). Por
        # defecto no hay ninguna mejora aplicada.
        self.bonus_speed = 0
        self.bonus_damage = 0

        self.shoot_cooldown_timer = 0.0
        self.last_move_dir = (1, 0)   # usado para apuntar el disparo aunque este quieto
        self._anim_time = 0.0
        self._leg_offset = 0

        self.bind(pos=self._redraw, size=self._redraw,
                  health=self._redraw, is_alive=self._redraw)
        self._redraw()

    # ------------------------------------------------------------
    # DIBUJO
    # ------------------------------------------------------------
    def _redraw(self, *args):
        self.canvas.clear()
        body_color = config.COLOR_ROBOT_BODY if self.is_alive else config.COLOR_ROBOT_BODY_DEAD
        accent_color = (config.COLOR_ROBOT_ACCENT if self.controlled_locally
                         else config.COLOR_ROBOT_ACCENT_REMOTE)
        bob = self._leg_offset

        with self.canvas:
            # Piernas (se mueven al caminar -> animacion simple)
            Color(*body_color)
            Rectangle(pos=(self.x + 4, self.y), size=(10, 16 + bob))
            Rectangle(pos=(self.x + self.width - 14, self.y), size=(10, 16 - bob))

            # Cuerpo
            Color(*body_color)
            Rectangle(pos=(self.x, self.y + 16), size=(self.width, self.height - 22))

            # Cabeza
            Color(*accent_color)
            head_size = self.width * 0.72
            Ellipse(pos=(self.x + (self.width - head_size) / 2, self.y + self.height - 22),
                    size=(head_size, head_size * 0.85))

            # "Ojo" que indica hacia donde mira el robot
            Color(0.05, 0.05, 0.08, 1)
            eye_x = self.x + self.width * (0.58 if self.facing_x >= 0 else 0.22)
            Ellipse(pos=(eye_x, self.y + self.height - 5), size=(8, 8))

        self._draw_health_bar()
        self._draw_name()

    def _draw_health_bar(self):
        bar_width = self.width
        bar_height = 6
        bar_x = self.x
        bar_y = self.y + self.height + 10
        pct = max(0.0, self.health) / self.max_health if self.max_health else 0

        fg_color = config.COLOR_HEALTH_FG if pct > 0.3 else config.COLOR_HEALTH_FG_LOW
        with self.canvas:
            Color(*config.COLOR_HEALTH_BG)
            Rectangle(pos=(bar_x, bar_y), size=(bar_width, bar_height))
            Color(*fg_color)
            Rectangle(pos=(bar_x, bar_y), size=(bar_width * pct, bar_height))

    def _draw_name(self):
        # Una pequena marca de color sobre la cabeza para diferenciar
        # visualmente al jugador local del jugador remoto en multijugador.
        if self.controlled_locally:
            return
        with self.canvas:
            Color(*config.COLOR_ROBOT_ACCENT_REMOTE)
            Rectangle(pos=(self.x + self.width / 2 - 10, self.y + self.height + 20),
                      size=(20, 4))

    # ------------------------------------------------------------
    # LOGICA (modo un jugador / control local)
    # ------------------------------------------------------------
    def update(self, dt, move_x, move_y):
        """Actualiza posicion y animacion. Solo debe llamarse sobre el
        jugador controlado localmente (en multijugador, el jugador
        remoto se actualiza con set_network_state en su lugar)."""
        if not self.is_alive:
            return

        speed = config.PLAYER_SPEED + self.bonus_speed

        if move_x != 0 or move_y != 0:
            length = (move_x ** 2 + move_y ** 2) ** 0.5
            nx, ny = move_x / length, move_y / length
            self.x += nx * speed * dt
            self.y += ny * speed * dt
            self.facing_x = 1 if nx >= 0 else -1
            self.last_move_dir = (nx, ny)

            self._anim_time += dt * 10
            self._leg_offset = 4 if int(self._anim_time) % 2 == 0 else -4
        else:
            self._leg_offset = 0

        # Limitar el movimiento dentro del mundo del juego
        self.x = max(0, min(self.x, config.WORLD_WIDTH - self.width))
        self.y = max(0, min(self.y, config.WORLD_HEIGHT - self.height))

        if self.shoot_cooldown_timer > 0:
            self.shoot_cooldown_timer -= dt

        self._redraw()

    def can_shoot(self):
        return self.is_alive and self.shoot_cooldown_timer <= 0

    def register_shot(self):
        self.shoot_cooldown_timer = config.PLAYER_SHOOT_COOLDOWN

    def take_damage(self, amount):
        if not self.is_alive:
            return
        self.health -= amount
        if self.health <= 0:
            self.health = 0
            self.is_alive = False

    def heal(self, amount):
        self.health = min(self.max_health, self.health + amount)

    def add_coins(self, amount):
        self.coins += amount

    # ------------------------------------------------------------
    # LOGICA (modo multijugador / jugador controlado por el servidor)
    # ------------------------------------------------------------
    def set_network_state(self, x, y, health, coins, facing_x):
        """Aplica el estado recibido del servidor. Se usa tanto para el
        jugador remoto como, en este proyecto, tambien para reflejar la
        vida/monedas autoritativas del propio jugador local (la
        posicion en pantalla del jugador local la sigue llevando el
        movimiento local para que se sienta responsivo; ver
        game_screen.py para el detalle de esta decision)."""
        self.pos = (x, y)
        self.health = health
        self.coins = coins
        self.facing_x = facing_x
        self.is_alive = health > 0
        self._redraw()
