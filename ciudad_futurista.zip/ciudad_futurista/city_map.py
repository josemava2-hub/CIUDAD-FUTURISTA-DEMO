"""
city_map.py
===========
Dibuja el fondo de "Ciudad Futurista": cielo azul degradado, edificios
grises con ventanas, y el suelo. Todo se dibuja con formas geometricas
de Kivy (sin imagenes externas), lo que hace que el mapa sea facil de
modificar: cambia los colores en config.py, o ajusta los rangos de
random en "_generate_buildings" para edificios mas altos, mas anchos,
mas juntos, etc.

El mapa es mas ancho que la pantalla (config.WORLD_WIDTH); la "camara
2D" se implementa en game_screen.py moviendo el contenedor del mundo
(que incluye este mapa) en sentido opuesto al jugador, dando la
sensacion de que la camara lo sigue por la ciudad.
"""
import random

from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle

import config


class CityMap(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size = (config.WORLD_WIDTH, config.WORLD_HEIGHT)
        self.size_hint = (None, None)
        self.pos = (0, 0)

        self._buildings = self._generate_buildings()

        self.bind(pos=self._redraw, size=self._redraw)
        self._redraw()

    def _generate_buildings(self):
        # Semilla fija: la ciudad siempre se genera igual, lo que hace
        # el juego mas predecible y facil de depurar/probar.
        rng = random.Random(42)
        buildings = []
        x = 0
        while x < config.WORLD_WIDTH:
            w = rng.randint(60, 140)
            h = rng.randint(120, 340)
            color = config.COLOR_BUILDING_1 if rng.random() > 0.5 else config.COLOR_BUILDING_2
            buildings.append({"x": x, "w": w, "h": h, "color": color})
            x += w + rng.randint(10, 30)
        return buildings

    def _redraw(self, *args):
        self.canvas.clear()
        ground_height = 60

        with self.canvas:
            # ---- Cielo (dos franjas para simular un degradado simple) ----
            Color(*config.COLOR_SKY)
            Rectangle(pos=(self.x, self.y + config.WORLD_HEIGHT * 0.35),
                      size=(config.WORLD_WIDTH, config.WORLD_HEIGHT * 0.65))
            Color(*config.COLOR_SKY_DARK)
            Rectangle(pos=(self.x, self.y + ground_height),
                      size=(config.WORLD_WIDTH, config.WORLD_HEIGHT * 0.35 - ground_height))

            # ---- Edificios ----
            for b in self._buildings:
                Color(*b["color"])
                Rectangle(pos=(self.x + b["x"], self.y + ground_height), size=(b["w"], b["h"]))

                # Ventanas iluminadas al azar, estilo ciudad nocturna futurista
                Color(*config.COLOR_BUILDING_WINDOW)
                rows = max(1, int(b["h"] // 24))
                cols = max(1, int(b["w"] // 20))
                for row in range(rows):
                    for col in range(cols):
                        if (row * 7 + col * 13 + b["x"]) % 5 == 0:
                            continue
                        wx = self.x + b["x"] + 6 + col * 20
                        wy = self.y + ground_height + 8 + row * 24
                        Rectangle(pos=(wx, wy), size=(10, 12))

            # ---- Suelo con una linea futurista brillante ----
            Color(*config.COLOR_GROUND)
            Rectangle(pos=(self.x, self.y), size=(config.WORLD_WIDTH, ground_height))
            Color(*config.COLOR_GROUND_LINE)
            Rectangle(pos=(self.x, self.y + ground_height - 3),
                      size=(config.WORLD_WIDTH, 3))
