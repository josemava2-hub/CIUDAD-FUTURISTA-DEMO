"""
multiplayer_screen.py
======================
Pantalla para conectarse a una partida multijugador.

Ofrece dos opciones:
    - "CREAR PARTIDA": arranca un servidor (server.py) en un hilo en
      segundo plano dentro de esta misma aplicacion, y se conecta a el
      automaticamente. Pensado tipicamente para el jugador de PC/Windows,
      que actua como anfitrion.
    - "UNIRSE A PARTIDA": se conecta a la IP y puerto de un servidor que
      ya existe (por ejemplo, la IP local de la PC que actua de
      servidor). Pensado tipicamente para el jugador de Android, que se
      conecta desde el celular a esa IP dentro de la misma red Wi-Fi.

Para jugar entre una PC con Windows y un celular Android en la MISMA
red Wi-Fi:
    1) En la PC: pulsar "CREAR PARTIDA". La pantalla mostrara el puerto
       usado (5555 por defecto).
    2) Anotar la IP local de la PC (en Windows: abrir "cmd" y escribir
       "ipconfig", buscar "Direccion IPv4", algo como 192.168.1.10).
    3) En el celular: escribir esa IP en el campo "IP del servidor" y
       pulsar "UNIRSE A PARTIDA".

Este mismo flujo, sin cambiar nada de codigo, es el que se ampliaria en
el futuro para jugar por internet (usando la IP publica del servidor y
un puerto reenviado en el router, o un servidor alojado en la nube).
"""
import threading

from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.graphics import Color, Rectangle
from kivy.clock import Clock

import config
from server import GameServer


class MultiplayerScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.server_instance = None
        self.server_thread = None

        with self.canvas.before:
            Color(*config.COLOR_SKY_DARK)
            self._bg_rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_bg, size=self._update_bg)

        root = BoxLayout(orientation="vertical", padding=30, spacing=10)
        self.add_widget(root)

        root.add_widget(Label(text="[b]MULTIJUGADOR[/b]", markup=True, font_size="26sp",
                               size_hint=(1, 0.12)))

        root.add_widget(Label(text="Tu nombre:", size_hint=(1, 0.06), font_size="13sp"))
        self.name_input = TextInput(text="Jugador1", multiline=False, size_hint=(1, 0.1))
        root.add_widget(self.name_input)

        root.add_widget(Label(
            text="IP del servidor (usa 127.0.0.1 si tu vas a crear la partida):",
            size_hint=(1, 0.1), font_size="13sp"))
        self.host_input = TextInput(text="127.0.0.1", multiline=False, size_hint=(1, 0.1))
        root.add_widget(self.host_input)

        root.add_widget(Label(text="Puerto:", size_hint=(1, 0.06), font_size="13sp"))
        self.port_input = TextInput(text=str(config.DEFAULT_SERVER_PORT), multiline=False,
                                     size_hint=(1, 0.1))
        root.add_widget(self.port_input)

        self.status_label = Label(text="", size_hint=(1, 0.12), font_size="13sp",
                                   color=(1, 0.8, 0.5, 1))
        root.add_widget(self.status_label)

        btn_host = Button(text="CREAR PARTIDA (ser anfitrion)", size_hint=(1, 0.12))
        btn_host.bind(on_release=self._create_server)
        root.add_widget(btn_host)

        btn_join = Button(text="UNIRSE A PARTIDA", size_hint=(1, 0.12))
        btn_join.bind(on_release=self._join_server)
        root.add_widget(btn_join)

        btn_back = Button(text="VOLVER", size_hint=(1, 0.1))
        btn_back.bind(on_release=self._go_back)
        root.add_widget(btn_back)

    def _update_bg(self, *args):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size

    # ------------------------------------------------------------
    def _get_port(self):
        try:
            return int(self.port_input.text.strip())
        except ValueError:
            self.status_label.color = (1, 0.4, 0.4, 1)
            self.status_label.text = "Puerto invalido"
            return None

    def _create_server(self, *args):
        port = self._get_port()
        if port is None:
            return

        if self.server_instance is None:
            self.server_instance = GameServer(host="0.0.0.0", port=port)
            self.server_thread = threading.Thread(target=self.server_instance.start,
                                                    daemon=True)
            self.server_thread.start()
            self.status_label.color = (0.5, 1, 0.5, 1)
            self.status_label.text = (
                f"Servidor iniciado en el puerto {port}. Otros jugadores en tu misma "
                f"red Wi-Fi pueden unirse usando la IP local de este equipo.")

        self.host_input.text = "127.0.0.1"
        Clock.schedule_once(lambda dt: self._join_server(), 0.3)

    def _join_server(self, *args):
        port = self._get_port()
        if port is None:
            return
        host = self.host_input.text.strip() or "127.0.0.1"
        name = self.name_input.text.strip() or "Jugador"

        self.status_label.color = (1, 1, 0.6, 1)
        self.status_label.text = "Conectando..."

        # Se retrasa un instante para que la etiqueta "Conectando..." se
        # alcance a pintar en pantalla antes de la llamada bloqueante de
        # conexion (ver client.py: NetworkClient.connect).
        Clock.schedule_once(lambda dt: self._attempt_connect(host, port, name), 0.05)

    def _attempt_connect(self, host, port, name):
        game_screen = self.manager.get_screen("game")
        ok = game_screen.start_multiplayer(host, port, name)
        if ok:
            self.status_label.text = ""
            self.manager.current = "game"
        else:
            self.status_label.color = (1, 0.4, 0.4, 1)
            msg = "Error desconocido"
            if game_screen.network_client is not None and game_screen.network_client.error_message:
                msg = game_screen.network_client.error_message
            self.status_label.text = f"No se pudo conectar: {msg}"

    def stop_hosted_server(self):
        """Detiene el servidor local si esta pantalla llego a crear uno.
        Se llama al cerrar la aplicacion (ver main.py)."""
        if self.server_instance is not None:
            self.server_instance.stop()

    def _go_back(self, *args):
        self.manager.current = "menu"
