[app]

# ---------------------------------------------------------------------
# Informacion basica de la app
# ---------------------------------------------------------------------
title = Ciudad Futurista
package.name = ciudadfuturista
package.domain = org.ciudadfuturista

source.dir = .
source.include_exts = py,png,jpg,jpeg,atlas,kv,ttf,json

version = 1.0

# Requisitos: Python 3 + Kivy. python-for-android elegira una version
# de Python 3 compatible con la version de Kivy indicada (Kivy 2.3.1
# soporta oficialmente Python 3.8 a 3.13).
requirements = python3,kivy==2.3.1

# ---------------------------------------------------------------------
# Presentacion
# ---------------------------------------------------------------------
orientation = landscape
fullscreen = 1

# ---------------------------------------------------------------------
# Permisos de Android
# ---------------------------------------------------------------------
# INTERNET y ACCESS_NETWORK_STATE son imprescindibles para el modo
# multijugador (sockets TCP).
android.permissions = INTERNET,ACCESS_NETWORK_STATE

# ---------------------------------------------------------------------
# Configuracion de Android / API
# ---------------------------------------------------------------------
android.api = 34
android.minapi = 21
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a

# Aumenta el tiempo de espera de compilacion en equipos lentos.
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
