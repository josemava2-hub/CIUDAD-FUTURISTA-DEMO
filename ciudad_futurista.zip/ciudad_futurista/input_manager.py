"""
input_manager.py
=================
Unifica el manejo de la entrada del jugador:

    - En PC: teclado (WASD o flechas para moverse, ESPACIO para disparar).
    - En Android: controles tactiles (ver ui.py -> TouchDPad y ShootButton).

El resto del juego (game_screen.py, player.py) NO necesita saber si se
esta jugando en PC o en celular: solo llama a
"input_manager.get_movement_vector()" e "input_manager.is_shooting()".

La deteccion de plataforma es automatica gracias a "kivy.utils.platform":
    - Si platform es "android" o "ios": se muestran y usan los controles
      tactiles (el teclado normalmente no existe en esos dispositivos).
    - En cualquier otro caso (win, linux, macosx, ...): se usa el teclado.

Tanto el teclado como los botones tactiles usan la MISMA API interna
(press/release/set_shooting), por lo que anadir un nuevo tipo de control
en el futuro (por ejemplo un mando/gamepad) es tan simple como llamar a
esos mismos metodos.
"""
from kivy.core.window import Window
from kivy.utils import platform

DIRECTIONS = ("up", "down", "left", "right")

# Traduce teclas de teclado (WASD y flechas) a direcciones logicas.
KEY_TO_DIRECTION = {
    "w": "up", "up": "up",
    "s": "down", "down": "down",
    "a": "left", "left": "left",
    "d": "right", "right": "right",
}


class InputManager:
    def __init__(self):
        self.is_mobile = platform in ("android", "ios")
        self._pressed = set()
        self._shooting = False
        self._keyboard = None

        if not self.is_mobile:
            self._bind_keyboard()

    # ------------------------------------------------------------
    # TECLADO (PC / Windows / Linux / macOS)
    # ------------------------------------------------------------
    def _bind_keyboard(self):
        self._keyboard = Window.request_keyboard(self._on_keyboard_closed, None)
        if self._keyboard:
            self._keyboard.bind(on_key_down=self._on_key_down, on_key_up=self._on_key_up)

    def _on_keyboard_closed(self):
        if self._keyboard:
            self._keyboard.unbind(on_key_down=self._on_key_down, on_key_up=self._on_key_up)
        self._keyboard = None

    def _on_key_down(self, keyboard, keycode, text, modifiers):
        key = keycode[1]
        if key in KEY_TO_DIRECTION:
            self.press(KEY_TO_DIRECTION[key])
        elif key == "spacebar":
            self.set_shooting(True)
        return True

    def _on_key_up(self, keyboard, keycode):
        key = keycode[1]
        if key in KEY_TO_DIRECTION:
            self.release(KEY_TO_DIRECTION[key])
        elif key == "spacebar":
            self.set_shooting(False)
        return True

    def unbind_keyboard(self):
        """Libera el teclado. Util al cerrar la pantalla de juego."""
        if self._keyboard:
            self._on_keyboard_closed()

    # ------------------------------------------------------------
    # API COMUN (usada tanto por el teclado como por los controles
    # tactiles definidos en ui.py)
    # ------------------------------------------------------------
    def press(self, direction):
        if direction in DIRECTIONS:
            self._pressed.add(direction)

    def release(self, direction):
        self._pressed.discard(direction)

    def set_shooting(self, value):
        self._shooting = bool(value)

    def is_shooting(self):
        return self._shooting

    def get_movement_vector(self):
        """Devuelve una tupla (x, y) con valores entre -1 y 1 indicando
        la direccion de movimiento deseada. No esta normalizada a
        longitud 1 en diagonal a proposito: eso lo hace quien la usa
        (ver player.py), para poder reutilizar el mismo vector con
        distintos propositos si hiciera falta."""
        x = 0
        y = 0
        if "left" in self._pressed:
            x -= 1
        if "right" in self._pressed:
            x += 1
        if "up" in self._pressed:
            y += 1
        if "down" in self._pressed:
            y -= 1
        return x, y

    def reset(self):
        """Limpia todo el estado de entrada. Util al reiniciar la partida."""
        self._pressed.clear()
        self._shooting = False
