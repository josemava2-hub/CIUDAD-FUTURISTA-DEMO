# Ciudad Futurista

Juego 2D hecho con **Python + Kivy** (NO Pygame). Un robot defiende una
ciudad futurista de una invasion alienigena. Funciona con el MISMO
proyecto tanto en **Windows** como en **Android**, e incluye un modo
**multijugador cliente-servidor** por sockets.

---

## 1. Estructura del proyecto

```
ciudad_futurista/
├── main.py              # Punto de entrada, ScreenManager de Kivy
├── config.py             # TODAS las constantes ajustables (velocidades, vidas, colores...)
│
├── input_manager.py       # Teclado (PC) / controles tactiles (Android), automatico
├── ui.py                  # HUD, cruceta tactil (D-pad) y boton de disparo
│
├── player.py               # Clase Player: el robot (vida, animacion, disparo)
├── enemy.py                 # Enemy, FastAlien, TankAlien, MiniBoss, Boss
├── bullet.py                 # Proyectiles
├── coin.py                    # Monedas
├── city_map.py                 # Fondo: ciudad, edificios, cielo, suelo
├── level_manager.py             # Progresion de niveles (modo un jugador)
├── save_data.py                  # Guardar/cargar monedas y mejoras (JSON)
│
├── menu_screen.py                 # Pantalla: menu principal
├── game_screen.py                   # Pantalla: la partida en si (1 jugador y multijugador)
├── shop_screen.py                     # Pantalla: tienda de mejoras
├── defeat_screen.py                     # Pantalla: derrota / reiniciar
├── multiplayer_screen.py                  # Pantalla: crear/unirse a partida en red
│
├── protocol.py                              # Formato de los mensajes de red (JSON por socket)
├── server.py                                  # Servidor autoritativo (sin Kivy, sockets TCP)
├── client.py                                    # Cliente de red (sin Kivy, sockets TCP)
│
├── buildozer.spec                                 # Configuracion para compilar el APK de Android
├── requirements.txt                                 # Dependencias de Python (PC)
└── README.md                                          # Este archivo
```

Todos los archivos estan en la misma carpeta (sin subcarpetas) a
proposito, para que sea muy facil de navegar y modificar: solo tienes
que abrir el archivo con el nombre de lo que quieras cambiar.

---

## 2. Requisitos

- **Python 3.13** (tambien funciona con 3.9 - 3.12).
- **Kivy 2.3.1** (version estable actual; soporta oficialmente Python
  3.8 a 3.13).

Instalacion en Windows / Linux / macOS:

```bash
python -m venv venv
venv\Scripts\activate        # En Windows
# source venv/bin/activate   # En Linux/macOS

pip install -r requirements.txt
```

> Si `pip install kivy` da problemas en Windows, instala primero las
> dependencias precompiladas recomendadas por Kivy:
> `pip install "kivy[base]" kivy_deps.sdl2 kivy_deps.glew` (solo
> necesario en Windows con Python < 3.11; con Python 3.13 normalmente
> basta con `pip install kivy`).

---

## 3. Como jugar en PC (Windows)

```bash
python main.py
```

- **Movimiento**: W A S D o flechas del teclado.
- **Disparo**: mantener pulsada la tecla ESPACIO (dispara en la
  direccion en la que te estas moviendo, o en la ultima direccion
  usada si estas quieto).
- Los controles tactiles NO aparecen en PC: la deteccion de plataforma
  es automatica (ver `input_manager.py`).

---

## 4. Como compilar para Android (Buildozer)

Buildozer solo funciona en **Linux** (o WSL en Windows). Pasos
resumidos:

```bash
pip install buildozer cython
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf \
    libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev \
    libtinfo5 cmake libffi-dev libssl-dev

cd ciudad_futurista
buildozer android debug
```

El primer build tarda bastante (descarga el Android SDK/NDK). Al
terminar, el APK queda en `bin/ciudadfuturista-1.0-debug.apk`, listo
para instalar en tu celular (`adb install bin/*.apk`) o copiarlo
manualmente.

`buildozer.spec` ya incluye:
- `requirements = python3,kivy==2.3.1`
- `android.permissions = INTERNET,ACCESS_NETWORK_STATE` (imprescindible
  para el modo multijugador)
- `orientation = landscape`

---

## 5. Modo multijugador (PC + Android en la misma partida)

El multijugador usa **sockets TCP** (protocolo propio en JSON, ver
`protocol.py`). El servidor (`server.py`) es quien decide TODO
(posiciones, vidas, enemigos, monedas, disparos, nivel); los clientes
solo envian su entrada y dibujan lo que el servidor les indica. Esto
evita que cada jugador vea una partida distinta.

### Jugar entre una PC (Windows) y un celular (Android) en la misma Wi-Fi

1. **En la PC**: abre el juego, entra a `MULTIJUGADOR` y pulsa
   **"CREAR PARTIDA"**. Esto arranca el servidor dentro de la propia
   app y te conecta automaticamente como primer jugador.
2. Averigua la IP local de la PC (en Windows: `ipconfig` en la consola,
   busca "Direccion IPv4", por ejemplo `192.168.1.10`).
3. **En el celular Android** (conectado a la MISMA red Wi-Fi): abre el
   juego, entra a `MULTIJUGADOR`, escribe esa IP en "IP del servidor" y
   pulsa **"UNIRSE A PARTIDA"**.
4. Ambos jugadores ya estan en la misma partida: mismos enemigos, misma
   ciudad, mismas monedas.

### Ejecutar el servidor por separado (opcional)

Tambien puedes correr el servidor como proceso independiente (por
ejemplo en una PC dedicada, o mas adelante en un servidor en la nube):

```bash
python server.py --host 0.0.0.0 --port 5555
```

y luego, desde cualquier dispositivo, unirte con "UNIRSE A PARTIDA"
usando la IP de esa maquina.

### Preparado para jugar por Internet en el futuro

El servidor escucha en `0.0.0.0` (todas las interfaces) y el protocolo
(`protocol.py`) es independiente de la red local. Para jugar por
Internet solo haria falta:

- Reenviar el puerto TCP (5555 por defecto) en el router del jugador
  que actua de servidor (port forwarding), **o**
- Alojar `server.py` en un servidor con IP publica (un VPS economico
  es suficiente: no necesita GPU ni siquiera pantalla, ya que
  `server.py` no depende de Kivy).

No hace falta cambiar nada del codigo del cliente ni del servidor para
esto: solo la IP que se escribe en la pantalla de multijugador.

---

## 6. Sistema de juego

- **Personaje**: robot con barra de vida, animacion simple de piernas
  al caminar, y disparo con enfriamiento (`config.PLAYER_SHOOT_COOLDOWN`).
- **Enemigos**: alien normal, alien rapido (poca vida), alien tanque
  (mucha vida, lento), mini-jefe (cada 3 niveles) y jefe (cada 5
  niveles) — todo configurable en `config.py`.
- **Monedas**: los enemigos las sueltan al morir; se guardan entre
  partidas (`save_data.py`) y se gastan en la Tienda.
- **Tienda**: mejora velocidad, dano de disparo y vida maxima (5
  niveles cada una).
- **Niveles**: cada nivel aumenta la cantidad de enemigos; al
  limpiarlo, se avanza automaticamente al siguiente.
- **Pantalla de derrota**: muestra el nivel alcanzado y las monedas
  ganadas, con boton de reiniciar.

---

## 7. Limitaciones conocidas y como ampliarlas

Este proyecto prioriza tener TODO el flujo completo y funcionando
(menu -> partida -> tienda -> multijugador -> derrota) antes que pulir
cada detalle al maximo. Puntos claros para seguir ampliando:

- **Enemigos a distancia**: por ahora todos los enemigos atacan solo
  por contacto. `enemy.py` y `server.py` ya calculan la posicion mas
  cercana al jugador; anadir un ataque a distancia es cuestion de
  crear balas de tipo `owner="enemy"` (ya soportado por `bullet.py` y
  `config.COLOR_BULLET_ENEMY`) desde esa posicion.
- **Mejoras de la tienda en multijugador**: hoy solo se aplican en el
  modo un jugador. Para que tambien apliquen en red, se puede enviar
  el nivel de cada mejora dentro del mensaje `MSG_JOIN` (ver
  `protocol.py` y `server.py: _process_message`) y usarlo al crear el
  `ServerPlayer`.
- **Prediccion de movimiento (client-side prediction)**: en
  multijugador, la posicion de TODOS los jugadores (incluido el
  propio) viene del servidor, sin prediccion local. En red local
  (Wi-Fi) esto se siente practicamente instantaneo; para jugar por
  Internet con buena sensacion de respuesta, el siguiente paso natural
  seria mover al jugador local de forma optimista y corregirlo si el
  servidor reporta una posicion distinta.
- **Reconexion automatica**: si se corta la conexion, el cliente
  vuelve al menu principal; no hay reintento automatico todavia.

---

## 8. Solucion de problemas

- **"No se pudo conectar" en multijugador**: revisa que ambos
  dispositivos esten en la misma red Wi-Fi, que la IP escrita sea la
  de la PC que creo la partida, y que el firewall de Windows no este
  bloqueando el puerto 5555 (la primera vez que ejecutas
  `python main.py` y creas una partida, Windows suele preguntar si
  permitir el acceso a la red: hay que aceptarlo).
- **La app no arranca en Android / pantalla negra**: revisa los logs
  con `adb logcat *:S python:D` mientras se abre la app; casi siempre
  el error esta relacionado con `android.permissions` en
  `buildozer.spec` o con una version de `python-for-android`
  desactualizada (`buildozer android update`).
