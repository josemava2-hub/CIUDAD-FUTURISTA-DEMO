"""
server.py
=========
Servidor autoritativo del modo multijugador de "Ciudad Futurista".

El servidor es la UNICA fuente de verdad del juego cuando se juega en
modo multijugador: decide donde estan los enemigos, cuanta vida les
queda, donde caen las monedas, cuando un jugador recibe dano, etc.
Los clientes (Windows, Android) solo envian su entrada (hacia donde se
mueven y si estan disparando) y reciben el estado del mundo para
dibujarlo en pantalla.

Este diseno evita problemas de "desincronizacion" (que cada jugador vea
una version distinta de la partida) y deja el proyecto preparado para
crecer hacia partidas por internet: el servidor no depende de Kivy y
puede ejecutarse perfectamente en una maquina sin pantalla (por ejemplo
un VPS en la nube), solo hace falta reenviar el puerto TCP configurado
(por defecto 5555) o desplegarlo en un servidor con IP publica.

COMO EJECUTARLO
----------------
Desde la carpeta raiz del proyecto:

    python server.py
    python server.py --host 0.0.0.0 --port 5555

Con los valores por defecto, el servidor escucha en todas las interfaces
de red del equipo (0.0.0.0), por lo que:

    - Un jugador en la MISMA PC puede conectarse a 127.0.0.1
    - Un jugador en OTRO dispositivo de la MISMA red Wi-Fi/LAN puede
      conectarse usando la IP local del equipo servidor
      (por ejemplo 192.168.1.10; se puede ver con "ipconfig" en Windows
      o "ifconfig"/"ip addr" en Linux/Android-Termux).
    - Para jugar por INTERNET en el futuro, bastaria con reenviar el
      puerto 5555 en el router (port forwarding) o alojar este script
      en un servidor con IP publica; el protocolo (protocol.py) y el
      cliente (client.py) no necesitan cambios.
"""
import argparse
import math
import random
import socket
import threading
import time

import config
from protocol import (
    encode_message,
    MSG_JOIN,
    MSG_WELCOME,
    MSG_INPUT,
    MSG_STATE,
    MSG_PLAYER_LEFT,
    MSG_SERVER_FULL,
    SocketLineReader,
)

# Estadisticas de cada tipo de enemigo. Se definen aqui en forma de
# diccionario (en lugar de usar las clases de enemy.py) para que este
# archivo pueda funcionar SIN Kivy instalado.
ENEMY_STATS = {
    "alien": dict(speed=config.ALIEN_SPEED, health=config.ALIEN_HEALTH,
                  damage=config.ALIEN_DAMAGE, size=42, coin_reward=1),
    "fast_alien": dict(speed=config.FAST_ALIEN_SPEED, health=config.FAST_ALIEN_HEALTH,
                        damage=config.FAST_ALIEN_DAMAGE, size=34, coin_reward=1),
    "tank_alien": dict(speed=config.TANK_ALIEN_SPEED, health=config.TANK_ALIEN_HEALTH,
                        damage=config.TANK_ALIEN_DAMAGE, size=56, coin_reward=2),
    "miniboss": dict(speed=config.MINIBOSS_SPEED, health=config.MINIBOSS_HEALTH,
                      damage=config.MINIBOSS_DAMAGE, size=80, coin_reward=8),
    "boss": dict(speed=config.BOSS_SPEED, health=config.BOSS_HEALTH,
                 damage=config.BOSS_DAMAGE, size=120, coin_reward=25),
}

BULLET_LIFETIME = 2.5
COIN_PICKUP_RADIUS = config.COIN_PICKUP_RADIUS


# =====================================================================
# ENTIDADES DEL SERVIDOR (representacion "en memoria", sin graficos)
# =====================================================================
class ServerPlayer:
    def __init__(self, player_id, name, start_x, start_y):
        self.id = player_id
        self.name = name
        self.x = start_x
        self.y = start_y
        self.facing_x = 1
        self.move_dir = (1, 0)      # ultima direccion de movimiento (para apuntar disparos)
        self.pending_move = (0, 0)  # vector de movimiento recibido en el ultimo "input"
        self.health = config.PLAYER_MAX_HEALTH
        self.max_health = config.PLAYER_MAX_HEALTH
        self.coins = 0
        self.alive = True
        self.shooting = False
        self.shoot_cooldown = 0.0
        self.contact_cooldowns = {}   # enemy_id -> segundos restantes de invulnerabilidad


class ServerEnemy:
    _next_id = 1

    def __init__(self, enemy_type, x, y):
        self.id = ServerEnemy._next_id
        ServerEnemy._next_id += 1
        self.type = enemy_type
        stats = ENEMY_STATS[enemy_type]
        self.x = x
        self.y = y
        self.speed = stats["speed"]
        self.health = stats["health"]
        self.max_health = stats["health"]
        self.damage = stats["damage"]
        self.size = stats["size"]
        self.coin_reward = stats["coin_reward"]


class ServerCoin:
    _next_id = 1

    def __init__(self, x, y, value):
        self.id = ServerCoin._next_id
        ServerCoin._next_id += 1
        self.x = x
        self.y = y
        self.value = value


class ServerBullet:
    _next_id = 1

    def __init__(self, owner_id, x, y, dir_x, dir_y):
        self.id = ServerBullet._next_id
        ServerBullet._next_id += 1
        self.owner_id = owner_id
        self.x = x
        self.y = y
        self.dir_x = dir_x
        self.dir_y = dir_y
        self.alive_time = 0.0


# =====================================================================
# SERVIDOR PRINCIPAL
# =====================================================================
class GameServer:
    """Servidor autoritativo: acepta conexiones, simula el mundo a un
    ritmo fijo (config.SERVER_TICK_RATE veces por segundo) y difunde el
    estado a todos los clientes conectados.
    """

    def __init__(self, host="0.0.0.0", port=config.DEFAULT_SERVER_PORT):
        self.host = host
        self.port = port
        self.lock = threading.Lock()

        self.players = {}         # id -> ServerPlayer
        self.enemies = {}         # id -> ServerEnemy
        self.coins = {}           # id -> ServerCoin
        self.bullets = {}         # id -> ServerBullet
        self.client_sockets = {}  # id -> socket.socket

        self.level = 1
        self.enemies_to_spawn = 0
        self.pending_boss = None
        self.spawn_timer = 0.0
        self.game_over = False

        self._next_player_id = 1
        self._running = False
        self._server_socket = None

        self._start_level(1)

    # ----------------- PROGRESION DE NIVELES -----------------
    def _start_level(self, level):
        self.level = level
        self.enemies_to_spawn = (config.ENEMIES_PER_LEVEL_BASE +
                                  (level - 1) * config.ENEMIES_PER_LEVEL_INCREMENT)
        self.spawn_timer = 0.0
        self.pending_boss = None
        if level % config.BOSS_EVERY_N_LEVELS == 0:
            self.pending_boss = "boss"
        elif level % config.MINIBOSS_EVERY_N_LEVELS == 0:
            self.pending_boss = "miniboss"
        print(f"[Servidor] Nivel {level} iniciado "
              f"(enemigos a spawnear: {self.enemies_to_spawn}, jefe: {self.pending_boss})")

    def _random_enemy_type(self):
        roll = random.random()
        if roll < 0.55:
            return "alien"
        elif roll < 0.8:
            return "fast_alien"
        return "tank_alien"

    def _random_spawn_position(self):
        side = random.choice(["left", "right"])
        x = 10 if side == "left" else config.WORLD_WIDTH - 60
        y = random.uniform(70, config.WORLD_HEIGHT - 60)
        return x, y

    def _update_level_spawns(self, dt):
        if self.enemies_to_spawn > 0:
            self.spawn_timer -= dt
            if self.spawn_timer <= 0:
                self.spawn_timer = config.ENEMY_SPAWN_INTERVAL
                etype = self._random_enemy_type()
                x, y = self._random_spawn_position()
                enemy = ServerEnemy(etype, x, y)
                self.enemies[enemy.id] = enemy
                self.enemies_to_spawn -= 1
        elif self.pending_boss is not None and len(self.enemies) == 0:
            x, y = self._random_spawn_position()
            enemy = ServerEnemy(self.pending_boss, x, y)
            self.enemies[enemy.id] = enemy
            self.pending_boss = None
        elif (self.enemies_to_spawn == 0 and self.pending_boss is None
                and len(self.enemies) == 0 and self.players):
            self._start_level(self.level + 1)

    # ----------------- RED: ACEPTAR CONEXIONES -----------------
    def start(self):
        """Arranca el servidor. Esta llamada BLOQUEA el hilo actual con
        el bucle principal del juego, por lo que normalmente se ejecuta
        en su propio hilo (ver multiplayer_screen.py) o como script
        independiente (python server.py)."""
        self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_socket.bind((self.host, self.port))
        self._server_socket.listen(config.MAX_PLAYERS)
        self._running = True

        print(f"[Servidor] 'Ciudad Futurista' escuchando en {self.host}:{self.port}")
        threading.Thread(target=self._accept_loop, daemon=True).start()
        self._game_loop()

    def _accept_loop(self):
        while self._running:
            try:
                client_sock, addr = self._server_socket.accept()
            except OSError:
                break
            threading.Thread(target=self._handle_client, args=(client_sock, addr),
                              daemon=True).start()

    def _handle_client(self, client_sock, addr):
        reader = SocketLineReader(client_sock)
        player_id = None
        try:
            while self._running:
                for message in reader.read_messages():
                    player_id = self._process_message(client_sock, addr, player_id, message)
        except (ConnectionError, OSError):
            pass
        finally:
            if player_id is not None:
                self._remove_player(player_id)
            try:
                client_sock.close()
            except OSError:
                pass

    def _process_message(self, client_sock, addr, player_id, message):
        msg_type = message.get("type")

        if msg_type == MSG_JOIN:
            with self.lock:
                if len(self.players) >= config.MAX_PLAYERS:
                    self._send_to(client_sock, encode_message(MSG_SERVER_FULL))
                    return player_id

                new_id = self._next_player_id
                self._next_player_id += 1
                start_x = 100 + (len(self.players) * 90)
                start_y = 100
                raw_name = str(message.get("name", "")).strip()
                name = raw_name[:20] if raw_name else f"Jugador{new_id}"
                player = ServerPlayer(new_id, name, start_x, start_y)
                self.players[new_id] = player
                self.client_sockets[new_id] = client_sock

            self._send_to(client_sock, encode_message(MSG_WELCOME, {"player_id": new_id}))
            print(f"[Servidor] '{name}' (id={new_id}) conectado desde {addr}")
            return new_id

        elif msg_type == MSG_INPUT and player_id is not None:
            with self.lock:
                player = self.players.get(player_id)
                if player is not None:
                    move_x = float(message.get("move_x", 0) or 0)
                    move_y = float(message.get("move_y", 0) or 0)
                    player.shooting = bool(message.get("shooting", False))
                    length = math.hypot(move_x, move_y)
                    if length > 0.001:
                        nx, ny = move_x / length, move_y / length
                        player.pending_move = (nx, ny)
                        player.move_dir = (nx, ny)
                        player.facing_x = 1 if nx >= 0 else -1
                    else:
                        player.pending_move = (0, 0)
            return player_id

        return player_id

    def _send_to(self, sock, raw_bytes):
        try:
            sock.sendall(raw_bytes)
        except OSError:
            pass

    def _remove_player(self, player_id):
        with self.lock:
            self.players.pop(player_id, None)
            self.client_sockets.pop(player_id, None)
        self._broadcast(encode_message(MSG_PLAYER_LEFT, {"player_id": player_id}))
        print(f"[Servidor] Jugador {player_id} desconectado")

    def _broadcast(self, raw_bytes):
        with self.lock:
            sockets = list(self.client_sockets.values())
        for sock in sockets:
            self._send_to(sock, raw_bytes)

    # ----------------- BUCLE PRINCIPAL DEL JUEGO -----------------
    def _game_loop(self):
        tick_interval = 1.0 / config.SERVER_TICK_RATE
        last_time = time.time()
        while self._running:
            now = time.time()
            dt = min(now - last_time, 0.1)  # evita saltos grandes tras una pausa
            last_time = now

            with self.lock:
                self._simulate(dt)
                state = self._build_state_snapshot()

            self._broadcast(encode_message(MSG_STATE, state))
            time.sleep(tick_interval)

    def _simulate(self, dt):
        if self.game_over:
            return

        self._simulate_players(dt)
        self._update_level_spawns(dt)
        self._simulate_enemies(dt)
        self._simulate_bullets(dt)
        self._simulate_coin_pickups()

        if self.players and all(not p.alive for p in self.players.values()):
            self.game_over = True

    def _simulate_players(self, dt):
        for player in self.players.values():
            if player.alive:
                mx, my = player.pending_move
                player.x += mx * config.PLAYER_SPEED * dt
                player.y += my * config.PLAYER_SPEED * dt
                player.x = max(0, min(player.x, config.WORLD_WIDTH - config.PLAYER_SIZE[0]))
                player.y = max(0, min(player.y, config.WORLD_HEIGHT - config.PLAYER_SIZE[1]))

                if player.shoot_cooldown > 0:
                    player.shoot_cooldown -= dt
                if player.shooting and player.shoot_cooldown <= 0:
                    player.shoot_cooldown = config.PLAYER_SHOOT_COOLDOWN
                    dir_x, dir_y = player.move_dir
                    bullet = ServerBullet(
                        player.id,
                        player.x + config.PLAYER_SIZE[0] / 2,
                        player.y + config.PLAYER_SIZE[1] / 2,
                        dir_x, dir_y,
                    )
                    self.bullets[bullet.id] = bullet

            for enemy_id in list(player.contact_cooldowns.keys()):
                player.contact_cooldowns[enemy_id] -= dt
                if player.contact_cooldowns[enemy_id] <= 0:
                    del player.contact_cooldowns[enemy_id]

    def _simulate_enemies(self, dt):
        alive_players = [p for p in self.players.values() if p.alive]
        if not alive_players:
            return

        for enemy in list(self.enemies.values()):
            target = min(alive_players,
                         key=lambda p: (p.x - enemy.x) ** 2 + (p.y - enemy.y) ** 2)
            dx = target.x - enemy.x
            dy = target.y - enemy.y
            dist = math.hypot(dx, dy)
            if dist > 1:
                enemy.x += (dx / dist) * enemy.speed * dt
                enemy.y += (dy / dist) * enemy.speed * dt

            contact_range = enemy.size / 2 + 24
            if dist < contact_range and target.contact_cooldowns.get(enemy.id, 0) <= 0:
                target.health -= enemy.damage
                target.contact_cooldowns[enemy.id] = config.ENEMY_CONTACT_COOLDOWN
                if target.health <= 0:
                    target.health = 0
                    target.alive = False

    def _simulate_bullets(self, dt):
        for bullet in list(self.bullets.values()):
            bullet.x += bullet.dir_x * config.PLAYER_BULLET_SPEED * dt
            bullet.y += bullet.dir_y * config.PLAYER_BULLET_SPEED * dt
            bullet.alive_time += dt

            out_of_bounds = not (0 <= bullet.x <= config.WORLD_WIDTH
                                  and 0 <= bullet.y <= config.WORLD_HEIGHT)
            remove_bullet = bullet.alive_time > BULLET_LIFETIME or out_of_bounds

            if not remove_bullet:
                for enemy in list(self.enemies.values()):
                    dist = math.hypot(bullet.x - (enemy.x + enemy.size / 2),
                                       bullet.y - (enemy.y + enemy.size / 2))
                    if dist < enemy.size / 2 + 6:
                        enemy.health -= config.PLAYER_BULLET_DAMAGE
                        remove_bullet = True
                        if enemy.health <= 0:
                            self._on_enemy_killed(enemy)
                        break

            if remove_bullet:
                self.bullets.pop(bullet.id, None)

    def _on_enemy_killed(self, enemy):
        self.enemies.pop(enemy.id, None)
        should_drop = enemy.type in ("miniboss", "boss") or random.random() < config.COIN_DROP_CHANCE
        if should_drop:
            multiplier = 8 if enemy.type == "boss" else 3 if enemy.type == "miniboss" else 1
            coin = ServerCoin(enemy.x, enemy.y, config.COIN_VALUE * multiplier)
            self.coins[coin.id] = coin

    def _simulate_coin_pickups(self):
        for player in self.players.values():
            if not player.alive:
                continue
            for coin in list(self.coins.values()):
                dist = math.hypot(player.x - coin.x, player.y - coin.y)
                if dist < COIN_PICKUP_RADIUS:
                    player.coins += coin.value
                    self.coins.pop(coin.id, None)

    def _build_state_snapshot(self):
        return {
            "level": self.level,
            "game_over": self.game_over,
            "players": [
                {
                    "id": p.id, "name": p.name, "x": p.x, "y": p.y,
                    "facing_x": p.facing_x, "health": p.health,
                    "max_health": p.max_health, "coins": p.coins, "alive": p.alive,
                }
                for p in self.players.values()
            ],
            "enemies": [
                {
                    "id": e.id, "type": e.type, "x": e.x, "y": e.y,
                    "health": e.health, "max_health": e.max_health,
                }
                for e in self.enemies.values()
            ],
            "coins": [
                {"id": c.id, "x": c.x, "y": c.y} for c in self.coins.values()
            ],
            "bullets": [
                {"id": b.id, "x": b.x, "y": b.y, "owner_id": b.owner_id}
                for b in self.bullets.values()
            ],
        }

    def stop(self):
        self._running = False
        if self._server_socket:
            try:
                self._server_socket.close()
            except OSError:
                pass


# =====================================================================
# EJECUCION COMO SCRIPT INDEPENDIENTE
# =====================================================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Servidor de Ciudad Futurista")
    parser.add_argument("--host", default="0.0.0.0",
                         help="Direccion en la que escuchar (0.0.0.0 = todas las interfaces)")
    parser.add_argument("--port", type=int, default=config.DEFAULT_SERVER_PORT,
                         help="Puerto TCP en el que escuchar")
    args = parser.parse_args()

    server = GameServer(host=args.host, port=args.port)
    try:
        server.start()
    except KeyboardInterrupt:
        print("\n[Servidor] Cerrando...")
        server.stop()
